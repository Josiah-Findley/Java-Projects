/************************************************
**Josiah Findley ~ COMP233.A ~ Spring 2020****
**
**Use divide and conquer to find the area under
**under a function using trapezoids.
**
** Code is adapted from http://www.carfield.com.h
**k/document/java/tutorial/Thread/Advance_thread.pdf.
*************************************************/

/* This interface evaluates x in a given function and stores
** a string value of what the function is.
*/
interface TheFunction {
	public double evaluate(double x);
	public String toString();
}

/* This class implements TheFunction and here
** uses the function 4.0/(1.0+x*x) to estimate pi.
*/
class MyFunction implements TheFunction {
	public double evaluate(double x) { return 4.0/(1.0+x*x); }
	public String toString() { return " 4.0/(1.0+x*x)"; }
}

/* This class implements Thread and here
** uses the function 4.0/(1.0+x*x) to estimate pi.
*/
class Area extends Thread {
	//Variable Dictionary	
	//the bounds of integration, the error, and the approximation
	private double p, q, epsilon, result;
	private TheFunction f;//The function being integrated over
	private static int numForked = 0;//Keeps track of num of threads used
	
	/*Constructor that takes in the bounds of integration,
	the epsilon, and the function. Also adds one to num threads forked.*/
	public Area(double a, double b, double eps, TheFunction fn) {
		p = a; q = b; epsilon = eps; f = fn;
		numForked++;
	}
	// Getter method for result ie approximation
	public double getResult() { return result; }
	
	// Getter method for getting total number of threads forked
	public int getNumForked() { return numForked; }
	
	//Calculates area of a trapezoid
	private static double trapezoidArea
	(double p, double q, TheFunction f) {
		double area =
				(Math.abs(q-p))/2 * (f.evaluate(p) + f.evaluate(q));
		return area;
	}
	
	//Controls what happens with the threads using divide and conquer
	public void run() {
		//Variable Dictionary
		//Calculate a trapezoid over the entire bounds
		double bigArea = trapezoidArea(p, q, f);
		//Calculate two trapezoids over 2 sub intervals
		double leftSmallArea = trapezoidArea (p, ((p+q)/2), f);
		double rightSmallArea = trapezoidArea(((p+q)/2), q, f);
		//Add the two subIntervals together
		double sumOfAreas = leftSmallArea + rightSmallArea;
		//Error of the area of the one trapezoid vs the 2 smaller ones.
		double relError = Math.abs(bigArea - sumOfAreas);
		
		//If error is smaller than epsilon pass back the approximation
		if (relError <= (epsilon * sumOfAreas)) result = bigArea;
		/*Otherwise have two threads spawn off and calculate the areas
		of the right and left trapezoids until the approximation is good enough*/
		else {
			Area leftArea = new Area(p, (p+q)/2, epsilon, f);
			leftArea.start();
			Area rightArea = new Area((p+q)/2, q, epsilon, f);
			rightArea.start();
			//Join the threads back together
			try { leftArea.join(); }
			catch (InterruptedException e) { /* ignored */ }
			try { rightArea.join(); }
			catch (InterruptedException e) { /* ignored */ }
			//Add together their final results
			result = leftArea.getResult() + rightArea.getResult();
		}
	}
}

class AdaptiveQuadrature {
	public static void main(String[] args) {
		//Variable Dictionary
		double a = 0, b = 0, epsilon = 0; // Error and bounds of integration
		
		//Header
		System.out.println("Josiah Findley ~ COMP233.A ~ Smart Trapezoidal Rule\n");
		
		//Grab the Error and bounds of integration from cmd line. 
		//Throw errors where need be.
		try {
			a = (Double.valueOf(args[0])).doubleValue();
			b = (Double.valueOf(args[1])).doubleValue();
			epsilon = (Double.valueOf(args[2])).doubleValue();
		} catch (NumberFormatException e) {
			System.out.println("improper format");
			System.exit(1);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("not enough command line arguments");
			System.exit(1);
		}
		
		//If bounds are wrong or epsilon is not > 0 throw error.
		if (b <= a || epsilon <= 0) {
			System.err.println("b <= a || epsilon <=0, exit");
			System.exit(1);
		}
		
		//Create a new function to integrate over.
		TheFunction fn = new MyFunction();
		
		//Print to console what is being printed over with what bounds and error
		System.out.println("Integrating " + fn + " from "
				+ a + " to " + b + " using an epsilon of " + epsilon);
		
		// Create a new object to keep track of the area
		Area area = new Area(a, b, epsilon, fn);
		
		//Start the timer
		long startTime = System.currentTimeMillis();		
		//Start the threads on integrating the area
		area.start();
		//Bring the threads values back together
		try { area.join(); }
		catch (InterruptedException e) { /* ignored */ }		
		//Store the result of integration
		double result = area.getResult();
		//Store the number of threads forked
		int numForked = area.getNumForked();
		//end timer
		long endTime = System.currentTimeMillis();
	
		//Print the results
		System.out.println("\nResult for" + fn + " = " + result+
				"\n\twith an error of " + (Math.PI - result)+
				" \n\tand a runtime of "+ (endTime-startTime)+ " mSecs."+
				"\n\n\tNumber of threads forked: "+ numForked);
		
		//Normal Termination
		System.out.println("\n\t<<Normal Termination>>\n");
		System.exit(0);
	}
}