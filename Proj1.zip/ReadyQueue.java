package proj1;

public class ReadyQueue {
 
 Process head;
 Process tail;
 int size;
 
 public ReadyQueue() {
  head = null;
  tail = null;
  size = 0;
 }
 
 public ReadyQueue(Process head) {
  this.head = head;
  tail = head;
  size = 1;
 }
 
 public int getNProcesses() {
  return size;
 }
 
 public void addProcess(Process c) {
	 if(isEmpty()) {
		 head = c;
		 tail = c;
		 size++;	 
	 }
	 else{
		 tail.setNext(c);
		 c.setPrevious(tail);
		 tail = c;
		 size++;
		 }
 }
 
 public String removeProcess() {
  String toRemove = head.getState();
  head = head.getNext();
  size--;
  return toRemove;
 }
 
 public void contextSwitch() {
  if(isEmpty()) {
   return;
  }
  Process newHead = head.getNext();
  tail.setNext(head);
  head.setNext(null);
  tail = head;
  head = newHead;
 }
 
 public boolean isEmpty() {
     return size==0;
   }
   
   public String toString() {
     String text = "List size: "+ size + " Elements: \n";
     Process current = head;
     while(current!= null) {
       text+=current.toString() + " \n";
       current = current.getNext();
       
     }
     
     return text;
   }


	
}
