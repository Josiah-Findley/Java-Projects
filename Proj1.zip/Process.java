package proj1;

import java.util.LinkedList;

import doublyLinked.doublyLinkedList;

public class Process {

 int pid;
 String name;
 String state;
 int timeslice;
 Process next;
 Process previous;
 LinkedList<String> files;  //make an array or a linked list
 //one or more variables to implement doubly linked list structure
 


public Process(int pid, String name) {
  this.pid = pid;
  this.name = name;
  state = "ready";
  timeslice = 1;
  files = new LinkedList<String>();
  //create empty files structure
 }
 
 public void openFile(String newfile) {
  //TODO: finish method
	 files.add(newfile);
	 
 }
 
 public void closeFile(String newfile) {
  //TODO: finish method
	 files.remove(newfile);
 }
 
 
 public String toString() {
     return "Process "+ pid +" "+ name+ " "+state;
     
  }
 
 public int getPid() {
  return pid;
 }

 public void setPid(int pid) {
  this.pid = pid;
 }

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getState() {
  return state;
 }

 public void setState(String state) {
  this.state = state;
 }

 public int getTimeslice() {
  return timeslice;
 }

 public void setTimeslice(int timeslice) {
  this.timeslice = timeslice;
 }

 public Process getNext() {
  return next;
 }

 public void setNext(Process next) {
  this.next = next;
 }

 public Process getPrevious() {
  return previous;
 }

 public void setPrevious(Process previous) {
  this.previous = previous;
 }
 
 public LinkedList<String> getFiles() {
	return files;
}

public void setFiles(LinkedList<String> files) {
	this.files = files;
}
 
}

