package proj1;

public class ProcessManager {
	
	static ReadyQueue queue = new ReadyQueue();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//create all processes
	  createProcess("systemd");
	  createProcess("agetty");
	  createProcess("chronyd");
	  createProcess("crond");
	  createProcess("dbus-daemon");
	  createProcess("firewalld");
	  createProcess("irqbalance");
	  createProcess("lvmetad");
	  createProcess("polkitd");
	  createProcess("sshd");
	  createProcess("rsyslogd");
		  
	  roundRobin();

		//sshd process opens two files: hello.c and hello.h.
		Process current = findProcess("sshd");
		current.openFile("hello.c");
		current.openFile("hello.h");
		
		//sshd process closes hello.c file.
		current.closeFile("hello.c");
		
		//terminate the process whose name is crond
		current = findProcess("crond");
		terminateProcess(current.getPid());
		System.out.println(queue);
		
		//terminates all the processes
		current = queue.head;
		while(current!= null) {
			Process a = current.getNext();
			terminateProcess(current.getPid());
			current = a;
		}
		
		System.out.println(queue);
		System.out.println("Normal Termination");
		

	}
	
	
	public static Process findProcess(String name) {
		Process current = queue.head;
		while(current!= queue.tail && current.getName()!= name) {
			current = current.getNext();
		}

		return current;
	}
	
	public static int createProcess(String name) {
		int pid;
		if(queue.isEmpty()) {
			 pid = 1; 		
		}
		else {
			pid = queue.tail.getPid()+1;
		}
		Process proc = new Process(pid, name);
		queue.addProcess(proc);
		return pid;
	}
	
	
	public static String terminateProcess(int pid) {
		if(queue.isEmpty()) {
			System.err.println("List is empty");
			return null;
			
		}
		Process current = queue.head;
		while(current!= queue.tail && current.getPid()!=pid) {
			current = current.getNext();
		}
		
		if(current.getPid()==queue.head.getPid()) {

			queue.head = current.getNext();
			--queue.size;
			current.setState("terminated");
			return current.getName();	
			
		}
		else {
			Process predeccesor = current.getPrevious();
			
			predeccesor.setNext(current.getNext());
			current.getNext().setPrevious(predeccesor);
			--queue.size;
			current.setState("terminated");
			return current.getName();
		}
	} 
	

	public static void roundRobin() {
		int i = queue.head.pid;
		
		System.out.println(queue.head.getPid()); 
		queue.contextSwitch();
		
		while(queue.head.pid != i) {
			System.out.println(queue.head.getPid()); 
			queue.contextSwitch();

			  }
		System.out.println(); 
			 }

}
