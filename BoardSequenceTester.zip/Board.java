import java.util.Scanner;

/**
 * 
 * @author Josiah Findley
 * A snapshot of a Game of Life board at one point in time
 */
public class Board {
	// TODO: declare any additional member variables
	
	// The two-dimensional grid of board cells.
	// cells[r][c] is true if the cell at row r and column c is alive.
	private boolean[][] cells;
	private int numRows;
	private int numCol;
	

	
	/**
	 * Creates a Board with no live cells
	 * @param numberOfRows - number of rows in the board
	 * @param numberOfColumns - number of columns in the board
	 */
	public Board(int numberOfRows, int numberOfColumns){
		cells = new boolean[numberOfRows][numberOfColumns];
		
		numRows=numberOfRows;
		numCol=numberOfColumns;
		
		for(int i=0; i<numberOfRows; i++) {
			for(int j=0; j<numberOfColumns; j++) {
				cells[i][j] = false;
			}
				
		}
	}
	
	
	/**
	 * Constructs a Board from the given String.
	 * @param boardInfo: Should be a String in the format specified in the instructions under "File Format"
	 *     The string should contain all of the lines, so it will have newlines in it.
	 * Example:
"Glider\n" +
"7\n" +
"8\n" +
"        \n" +
"  X     \n" +
"   X    \n" +
" XXX    \n" +
"        \n" +
"        \n" +
"        \n"
	 */
	public Board(String boardInfo){
		Scanner in= new Scanner(boardInfo);
		in.nextLine();
		numRows = in.nextInt();
		numCol = in.nextInt();
		in.nextLine();
		cells = new boolean[numRows][numCol];
		char c;
		
	
			
			for(int i=0; i<numRows; i++) {
					Scanner line = new Scanner(in.nextLine()); 
					line.useDelimiter("");
				for(int j=0; j<numCol; j++) {
					
					
						
					if(line.hasNext()) {
						c = line.next().charAt(0);

						
						if(Character.isLetter(c)) {
							cells[i][j] = true;
							
							}
						else if (Character.isWhitespace(c))
						{cells[i][j] = false;
					
						}
						
					}
						
					
					}
				line.close();
					
					
				
					
			}
		

	}
	
	
	/**
	 * @return number of rows in the board
	 */
	public int getNumRows(){
		return numRows;
	}
	
	/**
	 * @return number of columns in the board
	 */
	public int getNumCols(){ 
		return numCol;
	}
	
	
	
	
	/**
	 * @return value of the cell at the given @param row and @param col
	 * @throws IllegalArgumentException if row or col is out of bounds.
	 */
	public boolean getCell(int row, int col) throws IllegalArgumentException{
		try {
		return cells[row][col];
		}catch(IllegalArgumentException f) {
			return cells[row][col];
		}
		
	}
	
	
	/**
	 * @return A new Board for the next generation (i.e., after this).
	 *    The cell values for the next generation
	 *    are determined by the rules of Game of Life.
	 */
	public Board nextBoard(){
		
		//initializes board
		Board a = new Board(this.getNumRows(), this.getNumCols());
	
		// creates array that stores total number of living neighbors for each row.
		int livingNeighbors [][]= new int[a.getNumRows()][a.getNumCols()];
		
		
		
		//Finds number of living neighbors for each cell
		
		for(int i=0; i<a.getNumRows(); i++) {
			for(int j=0; j<a.getNumCols(); j++) {
		
				livingNeighbors [i][j]= neighbors(i,j); 

				}
		}	

		
		//Gives new status
				for(int i=0; i<a.getNumRows(); i++) {
					for(int j=0; j<a.getNumCols(); j++) {
						if(this.getCell(i,j)==true) {
							
							if(livingNeighbors [i][j]<2) {
								a.cells [i][j]=false;
							}
							else if(livingNeighbors [i][j]==2||livingNeighbors [i][j]==3){
								a.cells [i][j]= true;
							}
							else if(livingNeighbors [i][j]>3){
								a.cells [i][j]=false;
							}		
									
							}
							
							else {
								
							if(livingNeighbors [i][j]==3){
								a.cells [i][j]=true;
								}
								
							}	
						}	
						}
			
				return a;
				}	
	
	/** 
	 * This method gives the number of live neighbors of a given cell.
	 * 
	 * @param r The row we are checking.
	 * @param c The column we are checking.
	 * @return The number of live neighbors of a given cell
	 */
				
	
	private int neighbors(int r, int c) {
		int count =0;
		for(int i=-1; i<2; i++) {
			for(int j=-1; j<2; j++) {
				
				try {
					
				if(this.getCell(r+i,c+j) == true && (i!=0 || j!=0)) {
					count++;
				}
				
				}catch(Exception e) {
					
				}
					
				}
				
		}
		
		return count;	
		
	}

	/**
	 * @return true if other is the same size as this
	 *   and all of the cells of other have the same
	 *   values as this
	 */
	public boolean isSame(final Board other){
		for(int i=0; i<this.getNumRows(); i++) {
			for(int j=0; j<this.getNumCols(); j++) {
				if(this.getCell(i, j) != other.getCell(i, j)) {
					
					return false;
				}
				
				
			}
			
		}
		return true;
	}
	
	/**
	 * @return a String representation of the current board state
	 * Example:
	 *    ......\n
	 *    ......\n
	 *    .X....\n
	 *    ..X...\n
	 *    .XX...\n
	 *    ......\n
	 *    
	 *    Each row of the board should be printed on its own line.
	 *    The \n above represents a newline.
	 *    . characters are for dead cells.
	 *    X characters are for live cells.
	 *    The String should end with a newline.
	 */
	@Override
	public String toString(){
		String a = ""; 
		for(int i=0; i<this.getNumRows(); i++) {
			for(int j=0; j<this.getNumCols(); j++) {
				
				if(this.getCell(i, j)==true) {
					a += "X";
				}
				else{
					a += ".";
				}
				
		
			}
			a +="\n";
		}
		return a;
	}
	
	

}
