import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;



public class GameOfLife {
	
	/**
	 * This method converts a file into a long string
	 * 
	 * @param filename The name of the given file.
	 * @return  a String with the contents of the file. 
	 * @throws FileNotFoundException if file cannot be found
	 */
	
	public static String readFileContents(String filename) throws FileNotFoundException{
		File inputFile = new File(filename);
		Scanner in= new Scanner(inputFile);
		String allData = "";
		while(in.hasNextLine()) {
			allData += in.nextLine()+"\n";
		}

		return allData;
	}
	
	public static void main(String[] args) throws FileNotFoundException{
		
		//Gets input
		int numberGenerations =0;
		String sbfName= "";
		String pfile= "";
		Board start;
		
		
		// creates Generation 0
		while(true) {
		try {
			Scanner sbf = new Scanner(System.in);
			System.out.println("Enter the starting board file:");
			sbfName = sbf.next();
		start = new Board(readFileContents(sbfName));
		break;
		}catch(FileNotFoundException h) {
			
			System.out.println("Enter an actual file name (Glider, loaf, etc.).");
		}
		}
		
		
		
		//Gets number of Generations
	while(true) {
		try {
			Scanner numGen = new Scanner(System.in);
		System.out.println("Enter the number of generations:");
		numberGenerations = numGen.nextInt();
		break;
		}
		catch(InputMismatchException e) {
			System.out.println("Enter an actual natural number.");
			
		}
	}
		
			//prints file
			Scanner ofile = new Scanner(System.in);
			System.out.println("Enter the output file:");
			pfile= ofile.next();
			pfile = pfile+".txt";
			
	

		// creates a sequence to track the generations
		BoardSequence a = new BoardSequence(start);
		a.runMoreSteps(numberGenerations);

		

		//Prints Sequence
		PrintWriter outFile = new PrintWriter(pfile);
		outFile.print(a.toString());

		
		// Checks and prints cycle status
		if(a.findCycle()==-1) {
			outFile.print("\nNo cycles detected.");
			
		}
		else {
			
			outFile.print("\nCycle detected on generation "+ a.findCycle());
		}
		
		outFile.close();
		
	}

}
