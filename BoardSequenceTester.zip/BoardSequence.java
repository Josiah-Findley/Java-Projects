
public class BoardSequence {
	
	// Creates an initial board.
	private Board generation0;
	//Keeps track of total number in sequence.
	private int numberOfTotalSteps;
	
	/**
	 * Constructor initializes generation0 as the 0th generation and numberOfTotalSteps as 0/
	 * 
	 * @param startingBoard is the 0th
	generation in this BoardSequence.
	 */
	
	BoardSequence(Board startingBoard){
		generation0= startingBoard;
		numberOfTotalSteps=0;
	}
	
	
	/**
	 * Runs the world through an additional numSteps
	time steps. The starting point for these steps should be the most recent board (which will be the
	starting board if no steps have yet run). 
	 * 
	 * @param numSteps is the additional number of steps to run through.
	 */
	
	public void runMoreSteps(int numSteps){
		
		for(int i = 0; i<numSteps; i++) {
		numberOfTotalSteps++;		
		}	
		
		
		
	}
	
	/**
	 * Returns the Board at the specified index of the sequence.
	index should be between 0 and the number of steps run so far, inclusive. Otherwise,
	IllegalArgumentException is thrown. The starting Board is generation 0.

	 * @param index: is a int that tells which generation of the Board the method is expected to give.
	 * @return A board at the given index. 
	 */
	public Board boardAt(int index) {
		
		Board s = generation0;
		
		Board t = new Board(s.getNumCols(),s.getNumCols());
		
		for(int i = 0; i<index; i++) {
			
			t= s.nextBoard();
			s=t;
		}
		
		return s;
	
	}
	
	/**
	 * Gives a multi-line String that depicts the sequence of Boards.
	 * @return multi-line String that depicts the sequence of Boards
	 */
	public String toString() {
		String a="";
		for(int i = 0; i<numberOfTotalSteps; i++) {
			a+="Generation "+i+"\n";
			Board k = boardAt(i);
			a+= k.toString(); 
		}
		return a;
		
	}
	
	/**
	 * Checks the sequence of Boards and returns the index of the first time a cycle is detected
	 * @return The index of the first time a cycle is detected
	 */
	public int findCycle() {
		for(int i = 0; i<numberOfTotalSteps; i++) {
			Board k = boardAt(i);
			for(int j = 0; j<numberOfTotalSteps; j++) {
				Board l = boardAt(j);
				if(i!=j&& k.isSame(l)) {
					return j;
					
				}
				
			
			}
		
		}
		
		return -1;
	}
	
}
