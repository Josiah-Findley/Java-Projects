/************************************************
 **Josiah Findley ~ COMP233.A ~ Spring 2020****
 **
 **Use a Gui to create a beautiful interface for
 **our simple pi program.
 *************************************************/

//Imports are listed in full to show what's being used
//could just import javafx.*


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class GuiProjectPI extends Application {

	//Variable Dictionary
	private double a,b; //Interval bounds
	private long numStep; //num Intervals 
	//holds approx value, timer and error from pi
	private double error, approx, timeMillis; 

	//main method only contains the call to the launch method
	public static void main(String[] args) {
		launch(args);
	}

	//starting point for the application
	//code for the user interface
	@Override
	public void start(Stage primaryStage) {
		//The primaryStage is the top-level container
		primaryStage.setTitle("Josiah Findley ~ Pi with a GUI.");
		//Set up the borderPane
		BorderPane componentLayout = new BorderPane();
		componentLayout.setPadding(new Insets(20,20,20,20));
		
		//Header label
		Label EstimatePi = new Label("Estimate Pi!");
		EstimatePi.setId("header");

		//Set up rest of labels
		Label inputa = new Label("Enter Lower Bound (a):");
		Label inputb = new Label("Enter Lower Bound (b):");
		Label inputn = new Label("Enter num intervals (n):");
		Label result = new Label("Result of Integration:");
		Label errors = new Label("Error:");
		Label runTime = new Label("RunTime(sec):");
		Label comments = new Label("Comments:");
		Label Inputs = new Label("Inputs:");
		Label Outputs = new Label("Outputs:");


		//Set up Text Feilds
		TextField inputaT = new TextField ();
		inputaT.setPromptText("0.0");

		TextField inputbT = new TextField ();
		inputbT.setPromptText("1.0");

		TextField inputnT = new TextField ();
		inputnT.setPromptText("3000000");

		TextField resultT = new TextField ();
		resultT.setPromptText("approx");

		TextField errorT = new TextField ();
		errorT.setPromptText("Error:");

		TextField runTimeT = new TextField ();
		runTimeT.setPromptText("Run Time:");

		TextField commentsT = new TextField ();
		commentsT.setPromptText("Enter Inputs on the Left");

		//The button handles the calculate result
		Button calculate = new Button("Calculate Result!");
		
		calculate.setOnAction ((ActionEvent  e) -> {
			
				//Check if error was thrown
				boolean errorThrown = false;
			
				//Grabs the text from the fields
				String aStr = inputaT.getText();
				String bStr = inputbT.getText();
				String nStr = inputnT.getText();
				
				try {
				doOneRun( aStr,  bStr,  nStr);
				}catch(Exception e1) {
					commentsT.setText("Error in Inputs!");
					errorThrown = true;		
				}
				
				if(!errorThrown) {
				//Print Results
				String approxStr = String.format("%.10e", approx);
				resultT.setText(approxStr);
				
				String errorStr = String.format("%.2e", error);
				errorT.setText(errorStr);
				
				String runTimeStr = String.format("%.3e", timeMillis/1000);
				runTimeT.setText(runTimeStr);
				
				commentsT.setText("Done.");
				}

		});


		//Set up grid for inputs
		GridPane inputs = new GridPane();
		//Setting the vertical and horizontal gaps between the columns 
		inputs.setVgap(5); 
		inputs.setHgap(5);       

		//Setting the Grid alignment 
		inputs.setAlignment(Pos.CENTER); 
		inputs.add(inputa, 0, 0); 
		inputs.add(inputaT, 1, 0); 
		inputs.add(inputb, 0, 1);       
		inputs.add(inputbT, 1, 1); 
		inputs.add(inputn, 0, 2); 
		inputs.add(inputnT, 1, 2);  


		//Set up grid for outputs
		GridPane outputs = new GridPane();
		//Setting the vertical and horizontal gaps between the columns 
		outputs.setVgap(5); 
		outputs.setHgap(5);       

		//Setting the Grid alignment 
		outputs.setAlignment(Pos.CENTER); 
		outputs.add(result, 0, 0); 
		outputs.add(resultT, 1, 0); 
		outputs.add(errors, 0, 1);       
		outputs.add(errorT, 1, 1); 
		outputs.add(runTime, 0, 2); 
		outputs.add(runTimeT, 1, 2); 


		//Set the header
		componentLayout.setTop(EstimatePi);

		//position inputs and outputs
		componentLayout.setLeft(inputs);
		componentLayout.setRight(outputs);

		//position the bottom 
		GridPane bottom = new GridPane();
		//Setting the vertical and horizontal gaps between the columns 
		bottom.setVgap(5); 
		bottom.setHgap(375);       

		//Setting the Grid alignment 
		bottom.setAlignment(Pos.CENTER); 
		bottom.add(calculate, 0, 1); 
		bottom.add(comments, 1, 0); 
		bottom.add(commentsT, 1, 1); 

		//position the bottom
		componentLayout.setBottom(bottom);

		//Set an Id for the layout
		componentLayout.setId("pane");
		
		//Add the BorderPane to the Scene
		Scene appScene = new Scene(componentLayout,670,300);
		//Apply style sheet
		appScene.getStylesheets().addAll(this.getClass().getResource("Gui.css").toExternalForm());
		//Add the Scene to the Stage
		primaryStage.setScene(appScene);
		primaryStage.show();
	}

	//Adapted from Tim Mattson at intel with OPENMP
	//Receives: values for lowBound, hiBound & numSteps
	//Returns: The approximate value for pi
	public double serial(long numStep, double a, double b)
	{
		//Variables
		int i; double x, pi, sum = 0.0; //Used to calc. pi
		double start_time, run_time; //Used to track the timings
		double step = 1.0 / (double)numStep; //calc. step size for intervals

		long startTime = System.currentTimeMillis();
		for (i = 0; i < numStep; i++) { //runs through each step
			//calculates sum for the step
			x = (i + 0.5) * step;
			sum = sum + 4.0 / (1.0 + x * x);
		}

		// adds sum*stepsize to pi
		pi = step * sum;

		long endTime = System.currentTimeMillis();

		return pi;
	}/*serial*/

	//doOneRun
	//  Intellectual Property Credit goes to Dr. Valentine.
	//	Receives: string input values for lowBound, hiBound & numSteps
	//	Converts those to appropriate numeric types 
	//	Calls Mattson's simple, serial Riemann Sum PI approximation (with Timing)
	//	Returns results (approx, timeMillis & error) to Class variables

	private void doOneRun(String aStr, String bStr, String nStr){
		//Convert strings to numeric values
		//a, b & numSteps are private data elements of the class
		try {
			a = Double.valueOf(aStr.trim()).doubleValue();
			b = Double.valueOf(bStr.trim()).doubleValue();
			numStep = Integer.parseInt(nStr.trim());
		}
		catch(Exception e) {
			   //Throws exception
				throw e;
		}

		//Time & execute Mattson's simplest function- refactored
		//   to receive lowBound, hiBound & numSteps as parameters
		double startT = System.currentTimeMillis();
		approx = serial(numStep,a,b);
		double stopT = System.currentTimeMillis();

		//store results into our Class variables (approx is also a class variable)
		timeMillis = stopT-startT;
		error = Math.abs(Math.PI-approx);
	}



}
