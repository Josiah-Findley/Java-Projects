package yahtzee;

public class player {
	private String name;

	/**
	 * Constructs 
	 * @param name
	 */
	player(String name){
		this.setName(name);
	
		
		
	}
	
	/**
	 * Gets the name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * To make sure that there are no duplicate players
	 * 
	 * @returns true if is equals
	 */
	@Override
	public boolean equals(Object o) {
		
		if (this == o) {return true;}
		
		if (!(o instanceof player)) {return false;}
		
		player c = (player) o;
		return (name.equals(c.getName()));
	}
	
	/**
	 * 
	 * @returns hashCode value
	 */
	@Override
	public int hashCode() {
		
		int result = 17;
		result = 37 * result + Double.valueOf(name).hashCode();
		
		return result;
	}

	
	
	
	
	
	
	
	
	
	

}
