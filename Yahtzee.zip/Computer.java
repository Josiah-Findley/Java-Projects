package yahtzee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Computer extends player{

	Computer(String name) {
		super(name);
	
	}



}
