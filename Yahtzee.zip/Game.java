package yahtzee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Game {
	
	private int HumPlayers;
	private int AIPlayers;
	private int numPlayers;
    private int gameTurn;
	protected ArrayList<player> players;
	private scores scoreboard;
	
	/**
	 * Initializes HumPlayers, AIPlayers, players, scoreboard and gameTurn
	 */
	Game(int HumPlayers, int AIPlayers){
	this.AIPlayers = AIPlayers;
	this.HumPlayers = HumPlayers;
	players = new ArrayList<>();
	askForNames(HumPlayers, AIPlayers);
	numPlayers = HumPlayers + AIPlayers;
	scoreboard = new scores(players);
	}
	


	
	/**
	 * 
	 * 
	 * A for loop that iterates 13 times will run for the 13 rounds of the game.
	 * The game will end at the end of the 13 rounds and the player with highest score will be announced.
	 *  
	 *
	 */
	public void run () {
		
		for(int i =0; i<13; i++) {
			for(int j =0; j<HumPlayers; j++) {
				takeTurnH (j);
				scoreboard.toString(players);
				
			}
			for(int k =HumPlayers; k<numPlayers; k++) {
				takeTurnC (k);
				scoreboard.toString(players);
				
			}
			
		}
		
		System.out.println("The winner is: " +winner());
		
	}
	

	/**
	 * runs through a turn of a player. Creates an instance of dice.
	 * updates score.
	 * @param gameTurn keeps track of whose turn it is.
	 * 
	 */
	private void takeTurnH (int turn) {
		System.out.println("\nIt is "+players.get(turn).getName()+"'s turn.");
		System.out.println("\nYour roll is: ");
		Dice a = new Dice();
		a.rollDice();
		System.out.println(a.toString());
		
		for(int i =0; i<2; i++) {
		ArrayList<Integer> chose = chooseDice(a.getRolled());
		
		System.out.println("\nYour second roll is: ");
		a.rollCertainDice(chose);
		System.out.println(a.toString());
		}
		
		System.out.println("\nYour final roll is: "+ a.toString());
		
		System.out.println();
		scoreboard.toString(turn, players);
		scoreboard.chooseScoreLocationH(turn, a.getRolled());
		
		
	}
	
	/**
	 * runs through a turn of a computer. Creates an instance of dice.
	 * updates score.
	 * @param turn who's turn it is
	 */
	
	
	private void takeTurnC (int turn) {
		System.out.println("\nIt is "+players.get(turn).getName()+"'s turn.");
		System.out.println("\nYour roll is: ");
		Dice a = new Dice();
		a.rollDice();
		System.out.println(a.toString());
		
		for(int i =0; i<2; i++) {
		ArrayList<Integer> chose = bestDice(a.getRolled(), turn);
		

		System.out.println("\nYour second roll is: ");

		System.out.println();
		a.rollCertainDice(chose);
		System.out.println(a.toString());
		}

		System.out.println("\nYour final roll is: "+ a.toString());

		System.out.println();
		int loc = scoreboard.bestCategory(a.getRolled(), turn);
		scoreboard.updateComputerScore(turn, loc, a.getRolled()); 
		
	}
	
	/**
	 * Allows the player to choose what dice they would like to keep
	 * 
	 * @param diceRolled the dice that were just rolled
	 * @return choosenDice which is the dice kept
	 * @throws Exception if person isn't returning valid dice rolls
	 */
	
	private ArrayList<Integer> chooseDice(ArrayList<Integer> diceRolled){
		
		ArrayList<Integer> choosenDice = new ArrayList<>();
		boolean t = true;
		boolean r = true;
		
		while(t==true) {
		Scanner kept2 = new Scanner(System.in); 
		System.out.println("\nPlease choose which dice you would like to keep: ");
		
		Scanner kept = new Scanner(kept2.nextLine()); 
		r = true;
		while(kept.hasNext()&&r == true) {

		
			try {
			int k = kept.nextInt();
			
			
			if(k>=0&&k<7) {
				
				choosenDice.add(k);
				t= false;
				
			}
			else {
				
				throw new Exception("Please only choose integers between 1-6.");
				
			}
		
			
			
			
			}
			catch (InputMismatchException e){
				kept.next();
				System.out.println("Please only choose integers between 1-6.");
				choosenDice.clear();
				t =true;
				r = false;
				
			}
			
			
			catch (Exception ugh){
				
				System.out.println("Please only choose integers between 1-6.");
				choosenDice.clear();
				t =true;
				r = false;
			
			}
			
			
			
		}


			//Checks number of chosen specific dice vs number in dice rolled
		try {
			for(int z: choosenDice) {
				
				int occurrences = Collections.frequency(choosenDice, z);
				int occurrences2 = Collections.frequency(diceRolled, z);
			
			
		if (occurrences>occurrences2) {
			throw new Exception("Please only choose integers between 1-6 that have been rolled.");
			
		}
			}
		}
		catch (Exception er){
			
			System.out.println("Please only choose integers that have been rolled.");
			choosenDice.clear();
			t =true;
			
		
		}
		
		}
		
		return choosenDice;
		
	}
	
	
	
	
	
	
	
	/**
	 * 
	 * @param Dice passes in the dice that were just rolled
	 * @param turn who's turn it is
	 * @return the dice the computer chooses to keep
	 */
	
	public ArrayList<Integer> bestDice(ArrayList<Integer> Dice, int turn) {
		int[] occ = new int[6];
		ArrayList<Integer> choosenDice = new ArrayList<>();
		// Occurrence
		int occurrences =0;
		int oc1=0;
		
		for(int r=0; r<6; r++) {
			occurrences = Collections.frequency(Dice, r+1);
			 occ[r] = occurrences;
			 if(occurrences==1||occurrences==2) oc1++;
		}
		
		 int max = Arrays.stream(occ).max().getAsInt();

		// ai for dice 5 (Yahtzee)
		 if(max ==5 && scoreboard.getPlayerScores()[13][turn]==1000) {
			 for(int d: Dice) {
				 choosenDice.add(d);
			 }
			 
			 return choosenDice;}

		
		
		// ai for dice 3 or more
		for(int r=5; r>2; r--) {

		
		if(occ[r]>=3 && (scoreboard.getPlayerScores()[13][turn]==1000||scoreboard.getPlayerScores()[r][turn]==1000||scoreboard.getPlayerScores()[8][turn]==1000 || scoreboard.getPlayerScores()[9][turn]==1000|| scoreboard.getPlayerScores()[14][turn]==1000)) {
			
			for(int s=0; s<occ[r]; s++) {
				 choosenDice.add(r+1);	
			}
			return choosenDice;
			
		}
		
		}
		
		// ai for dice 3 or more
		for(int r=2; r>=0; r--) {

			
		if(occ[r]>=3 && (scoreboard.getPlayerScores()[r][turn]==1000|| scoreboard.getPlayerScores()[10][turn]==1000)) {
			
			
			for(int f=5; f>=0; f--) {
				if(occ[f]==2) {choosenDice.add(f+1);	choosenDice.add(f+1);	}
				
			}
			
			
			
			
			for(int s=0; s<occ[r]; s++) {
				 choosenDice.add(r+1);	
			}
			
			return choosenDice;
		}
		
		}
		
		
		// ai for dice pair
		for(int r=5; r>2; r--) {

			
		if(occ[r]>=2 && (scoreboard.getPlayerScores()[13][turn]==1000||scoreboard.getPlayerScores()[r][turn]==1000||scoreboard.getPlayerScores()[8][turn]==1000 || scoreboard.getPlayerScores()[9][turn]==1000|| scoreboard.getPlayerScores()[14][turn]==1000)) {
			
			for(int s=0; s<occ[r]; s++) {
				 choosenDice.add(r+1);	
			}
			return choosenDice;
			
		}
		
		}
		
		// ai for large straight
if(oc1==5 && (scoreboard.getPlayerScores()[11][turn]==1000 || scoreboard.getPlayerScores()[12][turn]==1000)) {
			
			for(int r=0; r<5; r++) {
			
				 if(occ[r]==1||occ[r]==2) choosenDice.add(r+1);
			}
		System.out.println(choosenDice);
			return choosenDice;
		}
		
		for(int t=0; t<6; t++) {
			int s=0;
			
			if(occ[t]==2) {
				s=t;
			}
			
// ai for small straight
	
if(oc1==4 && (scoreboard.getPlayerScores()[11][turn]==1000 || scoreboard.getPlayerScores()[12][turn]==1000)&&scoreboard.getPlayerScores()[s][turn]!=1000) {
			
			for(int r=0; r<5; r++) {
			
				 if(occ[r]==1||occ[r]==2) choosenDice.add(r+1);
			}
		System.out.println(choosenDice);
			return choosenDice;
		}
		}
		
		
		// ai for dice pair
		for(int r=2; r>=0; r--) {

			
		if(occ[r]>=2 && (scoreboard.getPlayerScores()[r][turn]==1000|| scoreboard.getPlayerScores()[10][turn]==1000)) {
			
			for(int s=0; s<occ[r]; s++) {
				 choosenDice.add(r+1);	
			}
			return choosenDice;
			
		}
		
		}
		
		return choosenDice;
		

	}
	

	
	/**
	 * Creates an arrayList of all players
	 * 
	 * @param nHuman
	 * @param nComp
	 * @return arraylist with human player names and ai names
	 */
	
	private void askForNames(int nHuman, int nComp){
		for(int j =0; j<nHuman; j++) {
			Scanner getNames = new Scanner(System.in);  
		    System.out.println("Enter player "+(j+1)+"'s name. (3 Letter Abbr.)");
		    
		    
		    
		    boolean t=true;
		    String r ="";
			while(t==true) {
				
				
				
				try {
					r = getNames.nextLine();
					
					for (player p : players) {
						if (p.getName().equalsIgnoreCase(r)) {
							throw new IllegalArgumentException();
						}
					}
					
					
					if(r.length() != 3) {
						throw new Exception("3 letters.");
					}	
					
					t=false;
					
				}catch (IllegalArgumentException iae) {
					t = true;
					System.out.println("Name Already Taken, please try again.");
				
				}catch (Exception e) {
					t=true;
					System.out.println("Please enter a 3 Letter Abbr.");

				}

		    
			}
			players.add(new player(r));
		}
		for(int i =0; i<nComp; i++) {

		    players.add(new Computer("AI"+(i+1)));
			
		}
		
	}
	
	/**
	 * Finds and returns player with highest score
	 * 
	 * @return name of player with highest score
	 */
	private String winner() {
		
		int[] occ = new int[players.size()];
		
		String win="";
		
		int k =0;
		
		for(player a: players) {
			
			if(scoreboard.getScoreValues().get(a.getName())>k) {
				win = a.getName();
				k =scoreboard.getScoreValues().get(a.getName());
		
			}
			
			else if (scoreboard.getScoreValues().get(a.getName())==k) {
				win +=" and " +a.getName();
				k =scoreboard.getScoreValues().get(a.getName());
			}
			
			
			
		}

		return win;
	}
}
