package yahtzee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class main {

	/**
	 * Asks for number of Human players between 0-5, 
	 * asks for the number of AI player and number between 0-5, creates a game instance,
	 * and then runs the run method of game.
	 * @param args
	 */
	
	public static void main (String args[]) {
		  System.out.println("Welcome to Yahtzee!\n");
		
	    System.out.println("Please enter number of Human Players (0-5): ");
		boolean t=true;
	    int r =0;
	    while(t==true) {
			Scanner values = new Scanner(System.in);  
		
			
			
			try {
				if(values.hasNextInt()) {
				r = values.nextInt();

				
				if(r >= 6||r<0) {
					throw new Exception("(0-5)");
				}	
				
				t=false;
				}
				else {
					throw new Exception("(0-5)");
				}
			}catch (Exception e) {
				t=true;
				System.out.println("Enter valid number of Human Players (0-5): ");

			}

	    
		}
		
		
	    System.out.println("Please enter number of Computer Players (0-5): ");
	    
	    
	    
	    t=true;
	   int p =0;
		while(t==true) {
			Scanner values = new Scanner(System.in);  
		   
			
			
			try {
				
				
				p = values.nextInt();

				
				if(p >= 6||p<0) {
					throw new Exception("(0-5)");
				}	
				
				t=false;
				
			}catch (Exception e) {
				t=true;
				System.out.println("\nEnter valid number of Computer Players (0-5): ");

			}

	    
		}
		
		System.out.println();
		Game yahtzee = new Game(r,p);
		yahtzee.run();

		
}
		
	}
	
	

