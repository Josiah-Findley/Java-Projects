package yahtzee;

import java.util.ArrayList;

public class Dice {
	private ArrayList<Integer> rolled;

	/**
	 * Initializes  dice rolled 
	 */
	Dice(){
		
		rolled = new ArrayList<>();
	}
	/**
	 * 
	 * @return 5 random dice in an arrayList
	 */
	public void rollDice() {
		int faceValue;
		for(int i = 0; i < 5; i++) { 
		 faceValue = (int)(Math.random() * 6 + 1);
		 
		 rolled.add(faceValue);
		}
		
	}
	
/**
 * 
 * @param chosen values chosen to reroll
 * @return new set of random values for the unchosen values along with the chosen values
 */
	
	public void rollCertainDice(ArrayList<Integer> chosen) {
		rolled.clear();
		int size = 5-chosen.size();
		
		int faceValue;
		for(int i = 0; i < size; i++) { 
			 faceValue = (int)(Math.random() * 6 + 1);
			 
			 rolled.add(faceValue);
			}

		for(int i = 0; i < chosen.size(); i++) {  	
			int k= chosen.get(i);
			 rolled.add(k);
			}
		
		
		}

	
	/**
	 * 
	 * @return the values rolled
	 */
public ArrayList<Integer> getRolled() {

	return rolled;
}
	
public String toString() {
	String a ="";
	for(int i = 0; i < rolled.size(); i++) {   
	   a+=(rolled.get(i))+ " ";
	}  
	return a;
}
	
	
}
