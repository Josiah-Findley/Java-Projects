package yahtzee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

  

public class scores {

	// creates a scoreboard of player's scores
	private int [][] playerScores;
	private HashMap<String, Integer> scoreValues;
	private ArrayList<player> players2;
	
	/**
	 * Initializes playerScores
	 * 
	 */
	scores(ArrayList<player> allPlayers){
		
		scoreValues = new HashMap<>();
		playerScores = new int[17][allPlayers.size()];
		players2 = allPlayers;
		
		 for (int row = 0; row < playerScores.length; row++) {
			    for (int col = 0; col < playerScores[row].length; col++) {
			    	playerScores[row][col] = 1000;
			
			    }
			 }
		 
		 for(player a: allPlayers) {
		 
			 scoreValues.put(a.getName(), playerScores[16][allPlayers.indexOf(a)]);
		 
		 }
		
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a Yahtzee
	 */
	
	
	public boolean isYahtzee(ArrayList<Integer> finalDice) {
		
		for(int k=1; k<7; k++) {
			int occurrences2 = Collections.frequency(finalDice, k);
			
			if(occurrences2==5) {
				return true;
				
			}
			}
	
		
		return false;
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a three of a kind
	 */
	
	public boolean isThreeOfAKind(ArrayList<Integer> finalDice) {
		
		
		for(int k=1; k<7; k++) {
		int occurrences4 = Collections.frequency(finalDice, k);
		
		if(occurrences4>=3) return true;
		}
	
		
		return false;
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a large straight
	 */
	
	
	public boolean isLargeStraight(ArrayList<Integer> finalDice) {
		
		
		 if (finalDice.get(0)== 1 &&
				 finalDice.get(1) == 2 &&
						 finalDice.get(2) == 3 &&
								 finalDice.get(3) == 4 &&
										 finalDice.get(4) == 5) {
			 return true;
	        }
	         
		 if (finalDice.get(0)== 2 &&
				 finalDice.get(1) == 3 &&
						 finalDice.get(2) == 4 &&
								 finalDice.get(3) == 5 &&
										 finalDice.get(4) == 6) {
			 return true;
	        }
	
		
		return false;
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a small straight
	 */
	
	public boolean isSmallStraight(ArrayList<Integer> finalDice) {
	
		Set<Integer> set = new HashSet<>(finalDice);
		ArrayList<Integer>  noDups= new ArrayList<>();
		noDups.addAll(set);
		
		if(noDups.size()>3) {
		
			try {
		 if (noDups.get(0)== 1 &&noDups.get(1) == 2 &&noDups.get(2) == 3 &&noDups.get(3) == 4 
			||	noDups.get(0)== 2 &&noDups.get(1) == 3 &&noDups.get(2) == 4 &&noDups.get(3) == 5  
			||	noDups.get(0)== 3 &&noDups.get(1) == 4 &&noDups.get(2) == 5 &&noDups.get(3) == 6 
			||	noDups.get(1)== 3 &&noDups.get(2) == 4 &&noDups.get(3) == 5 &&noDups.get(4) == 6 
			) {
			 
			 return true;
	        }
		 
			}
			
			catch(Exception a) {}
		}
	
		
		return false;
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a four of a kind
	 */
	
	public boolean isFourOfAKind(ArrayList<Integer> finalDice) {
		
		
		for(int k=1; k<7; k++) {
		int occurrences4 = Collections.frequency(finalDice, k);
		
		if(occurrences4>=4) return true;
		}
	
		
		return false;
	}
	
	/**
	 * 
	 * @param finalDice final roll
	 * @return true if a full house
	 */
	
	public boolean isFullHouse(ArrayList<Integer> finalDice) {
		
		for(int k=1; k<7; k++) {
		int occurrences5 = Collections.frequency(finalDice, k);
		
		if(occurrences5==3) {
						
			for(int p=1; p<7; p++) {
				int occurrences6 = Collections.frequency(finalDice, p);
				
				if(occurrences6==2 && k!=p) {
								
						return true;
					
					
				}
				
				
				}
			
			
		}
		
		
		}
	
		
		return false;
	}
	
	
	
	
	
	/**
	 * Asks user for input on category and updates score where needed. Warns user if they are adding a score of zero to a category.
	 * @param a the player whose turn it is
	 * @param finalDice the final choice for the player's roll
	 */
	public void chooseScoreLocationH(int turn, ArrayList<Integer> finalDice) {

		Collections.sort(finalDice); 
		System.out.println();
		
		int location =0;
		
		boolean t=true;
		int scoreForRound =0;
		while(t==true) {
			
			Scanner loc = new Scanner(System.in); 
			System.out.println("Please choose a valid category.");
			
		try {
			location = loc.nextInt();
			//t=false;
			
			if(location<1||location>16||location==7||location==8) {
				throw new Exception("Please choose a valid category.");
			}	
			
			
			
		}catch (Exception e) {
			t=true;

		}
		
		
		
		
		 scoreForRound =0;
		
		for(int r=1; r<7; r++) {
		
			// Upper section
		if (location==r) {
			int occurrences = Collections.frequency(finalDice, r);
			
			scoreForRound += r*occurrences;
			
		}
		}
		
		//Lower Section
		
		//Yahtzee
		if (location==14) {
	
			if(isYahtzee(finalDice)==true) scoreForRound += 50;
		
		}
		
		
		//Full House
		if (location==11) {
					
					if(isFullHouse(finalDice)==true) scoreForRound += 25;

		}
		
		//Chance
				if (location==15) {			
					for(int s: finalDice) {					
						scoreForRound += s;
					}
				}
		
				//ThreeOfAKind
				if (location==9) {
					if(isThreeOfAKind(finalDice)==true) {
						
						for(int s: finalDice) {					
							scoreForRound += s;
						}
						
					}
					
				}
					//FourOfAKind
					if (location==10) {
						
						if(isFourOfAKind(finalDice)==true) {
							
							for(int s: finalDice) {					
								scoreForRound += s;
							}
							
						}	
				}
					
					
					//LargeStraight
					if (location==13) {
						if(isLargeStraight(finalDice)==true) scoreForRound += 40;
						}
					
					
					//SmallStraight
					if (location==12) {
						if(isSmallStraight(finalDice)==true) scoreForRound += 30;
						}
					
			try {
		if(playerScores[location-1][turn]!=1000 && t==false) {
				t=true;
			throw new Exception("Please only choose integers between 1-6 that have been rolled.");

		}
		else {
			t=false;
		}
		
				}
		catch(Exception chosen) {
			System.out.println("Please only choose categories that haven't been chosen.");
			
		}
				
				if(scoreForRound== 0 && t==false) {
					
					System.out.println("Choosing this category will result in a score of zero, do you wish to proceed. (y/n)");
					
				       Scanner s = new Scanner(System.in);
				        boolean foundresult = false;
				        while(!foundresult){
				           
				            String sread = s.next();
				            if(sread.equalsIgnoreCase("Y")) {t=false; foundresult = true;}
				            else if(sread.equalsIgnoreCase("N")) {t=true; foundresult = true;}
				            else {System.out.println("Please only choose (y/n)"); foundresult = false;}
				        }

				}

		}
		
		playerScores[location-1][turn] = scoreForRound;
		updateScores(turn);

	}
	
	/**
	 * updates the final scores in sections and overall
	 * 
	 * @param turn who's turn it is
	 */
	
	public void updateScores(int turn) {
		
		// Updates Upper Score
		int upscore = 0;
		
		  for (int i = 0; i < 6; i++) {  
			  
			  if(playerScores[i][turn] != 1000) upscore+= playerScores[i][turn];
		  }
		  if( upscore != 0) playerScores[6][turn] = upscore;
		  
		  if( upscore >= 63) playerScores[7][turn] = 35;
		  
		// Updates Lower Score
			int lowscore = 0;
			
			  for (int i = 8; i < 15; i++) {  
				 
				  if(playerScores[i][turn] != 1000) lowscore+= playerScores[i][turn];
			  }
			  if(lowscore != 0)  playerScores[15][turn] = lowscore;
		// Updates total score	  
			  if(lowscore+ upscore != 0)  playerScores[16][turn] = lowscore+ upscore;
			  if(lowscore+ upscore != 0&&playerScores[7][turn]!=1000)  playerScores[16][turn] = lowscore+ upscore+playerScores[7][turn];
			  
			  scoreValues.put(players2.get(turn).getName(), lowscore+ upscore);
		
	}
	
	
	/**
	 * 
	 * @param turn who's turn it is
	 * @param location where the computer is going
	 * @param finalDice an array of the computer's last roll
	 */
	
	
	public void updateComputerScore(int turn, int location, ArrayList<Integer> finalDice) {
		int scoreForRound =0;
			
		for(int r=1; r<7; r++) {
		
			// Upper section
		if (location==r) {
			int occurrences = Collections.frequency(finalDice, r);
			
			scoreForRound += r*occurrences;
			
		}
		}
		
		//Lower Section
		
		 scoreForRound =0;
			
		for(int r=1; r<7; r++) {
		
			// Upper section
		if (location==r) {
			int occurrences = Collections.frequency(finalDice, r);
			
			scoreForRound += r*occurrences;
			
		}
		}
		
		//Lower Section
		
		//Yahtzee
		if (location==14) {
	
			if(isYahtzee(finalDice)==true) scoreForRound += 50;
		
		}
		
		
		//Full House
		if (location==11) {
					
					if(isFullHouse(finalDice)==true) scoreForRound += 25;

		}
		
		//Chance
				if (location==15) {			
					for(int s: finalDice) {					
						scoreForRound += s;
					}
				}
		
				//ThreeOfAKind
				if (location==9) {
					if(isThreeOfAKind(finalDice)==true) {
						
						for(int s: finalDice) {					
							scoreForRound += s;
						}
						
					}
					
				}
					//FourOfAKind
					if (location==10) {
						
						if(isFourOfAKind(finalDice)==true) {
							
							for(int s: finalDice) {					
								scoreForRound += s;
							}
							
						}	
				}
					
					
					//LargeStraight
					if (location==13) {
						if(isLargeStraight(finalDice)==true) scoreForRound += 40;
						}
					
					
					//SmallStraight
					if (location==12) {
						if(isSmallStraight(finalDice)==true) scoreForRound += 30;
						}
					
					
					playerScores[location-1][turn] = scoreForRound;
					updateScores(turn);
		
	}
	
	
	
	
	/**
	 * Finds the best category for the computer to go in.
	 * 
	 * @param finalDice last roll for the computer
	 * @param turn who's turn it is
	 * @return the best location for the computer to go in.
	 */
	public int bestCategory(ArrayList<Integer> finalDice, int turn) {

		int[] occ = new int[6];
	int location = 0;
		// Occurrence
		int occurrences =0;

	
		for(int r=0; r<6; r++) {
			occurrences = Collections.frequency(finalDice, r+1);
			 occ[r] = occurrences;
		
		}
		
		 int max = Arrays.stream(occ).max().getAsInt();
		


		 if(isYahtzee(finalDice) && playerScores[13][turn]==1000) { return 14;}
		 
		
		 else if(isLargeStraight(finalDice) && ( playerScores[12][turn]==1000)) {
			return 13;
		}
		 
		 
		 else if(isSmallStraight(finalDice) && (playerScores[11][turn]==1000)) {
				return 12;
			}


		
		for(int r=5; r>2; r--) {
			if(occ[r]>=2) {
				
				  if(isFullHouse(finalDice) && (playerScores[10][turn]==1000)) {
						return 11;
					}
				  else if ((playerScores[r][turn]==1000)) {
						return r+1;
					}
				  else if(isFourOfAKind(finalDice) && (playerScores[9][turn]==1000)) {
					return 10;
				}
			 else if(isThreeOfAKind(finalDice) && (playerScores[8][turn]==1000)) {
					return 9;
				}
			 

			 
			}
			
			
		}
		
		for(int r=2; r>=0; r--) {

			if(occ[r]>=2) {
				 if(isFullHouse(finalDice) && (playerScores[10][turn]==1000)) {
						return 11;
					}

				 
				 else if ((playerScores[r][turn]==1000)) {
						return r+1;
					}
				 
				 
				  else if(isFourOfAKind(finalDice) && (playerScores[9][turn]==1000)) {
					return 10;
				}
			 else if(isThreeOfAKind(finalDice) && (playerScores[8][turn]==1000)) {
					return 9;
				}
			 
			
			 
			
				 
				 
				}
		
		}
		
		int loc = 0;
		
		  if ((playerScores[14][turn]==1000)) {
				return 15;
			}
		
		for(int r=16; r>=0; r--) {

			
			if ((playerScores[r][turn]==1000)&& r!= 7) {
				loc = r+1;
			}
		
		}
		return loc;
			
	}
	
	
	/**
	 *  @return a string of the whole scoreboard.
	 */
	
public void toString(ArrayList<player> allPlayers) {
	

	
	System.out.printf("%-40s", "Official Scoreboard:");
	
	
	for(player t: allPlayers) {
		System.out.print(" "+t.getName()+" ");
		
	}
	
	
	System.out.println();
	System.out.println("\nUpper Section:");
	
    for (int i = 1; i < 18; i++) {    
    	String cat = "";
    	
    	if(i==1) cat+="(Location "+i+") Ones: "; 
    	if(i==2) cat+="(Location "+i+") Twos: "; 
    	if(i==3) cat+="(Location "+i+") Threes: "; 
    	if(i==4) cat+="(Location "+i+") Fours: "; 
    	if(i==5) cat+="(Location "+i+") Fives: "; 
    	if(i==6) cat+="(Location "+i+") Sixes: "; 
    	if(i==7) cat+="Upper Score: "; 
    	if(i==8) cat+="Upper Bonus: "; 
    	if(i==9) cat+="(Location "+i+") Three of a kind: "; 
    	if(i==10) cat+="(Location "+i+") Four of a kind: "; 
    	if(i==11) cat+="(Location "+i+") Full House: "; 
    	if(i==12) cat+="(Location "+i+") Small Straight: "; 
    	if(i==13) cat+="(Location "+i+") Large Straight: "; 
    	if(i==14) cat+="(Location "+i+") Yahtzee: "; 
    	if(i==15) cat+="(Location "+i+") Chance: "; 
    	if(i==16) cat+="Lower Score: "; 
    	if(i==17) cat+="Total: ";
    	
    	//this equals to the row in our matrix.
    	
    	
    	
    	System.out.printf("%-41s", cat);
    	
        for (int j = 0; j < playerScores[1].length; j++) {   //this equals to the column in each row.
   
        	
        	
        	
        	if(playerScores[i-1][j]==1000) {
        		
        		 System.out.print("____ ");
        	}
        	else if(playerScores[i-1][j] < 10) {
        		
       		 System.out.print("_"+ playerScores[i-1][j]+ "__ ");
       	}
        	
        	else if(playerScores[i-1][j] >= 100) {
        		
        		System.out.print(playerScores[i-1][j] + "_ ");
        	}
        	else {
        		
        		System.out.print("_"+playerScores[i-1][j] + "_ ");
        	}
        		
           
        }
        System.out.println(); //change line on console as row comes to end in the matrix.
        
        if(i==8) {System.out.println(); System.out.println("Lower Section:");}
        if(i==16) System.out.println(); 
     }
	
		
		
	}
	
/**
 * 
 * @param a the player whose scores are being accessed
 * @return a string of the scoreboard of the specific player
 */

 public void toString(int turn, ArrayList<player> allPlayers) {
	 System.out.printf("%-40s", allPlayers.get(turn).getName()+"'s Scoreboard:");

		
		System.out.println();
		System.out.println("\nUpper Section:");
		
	    for (int i = 1; i < 18; i++) {    
	    	String cat = "";
	    	
	    	if(i==1) cat+="(Location "+i+") Ones: "; 
	    	if(i==2) cat+="(Location "+i+") Twos: "; 
	    	if(i==3) cat+="(Location "+i+") Threes: "; 
	    	if(i==4) cat+="(Location "+i+") Fours: "; 
	    	if(i==5) cat+="(Location "+i+") Fives: "; 
	    	if(i==6) cat+="(Location "+i+") Sixes: "; 
	    	if(i==7) cat+="Upper Score: "; 
	    	if(i==8) cat+="Upper Bonus: "; 
	    	if(i==9) cat+="(Location "+i+") Three of a kind: "; 
	    	if(i==10) cat+="(Location "+i+") Four of a kind: "; 
	    	if(i==11) cat+="(Location "+i+") Full House: "; 
	    	if(i==12) cat+="(Location "+i+") Small Straight: "; 
	    	if(i==13) cat+="(Location "+i+") Large Straight: "; 
	    	if(i==14) cat+="(Location "+i+") Yahtzee: "; 
	    	if(i==15) cat+="(Location "+i+") Chance: "; 
	    	if(i==16) cat+="Lower Score: "; 
	    	if(i==17) cat+="Total: ";
	    	
	    	//this equals to the row in our matrix.
	    	
	    	
	    	
	    	System.out.printf("%-41s", cat);
	    	
	        for (int j = turn; j < turn+1; j++) {   //this equals to the column in each row.
	   
	        	
	        	
	        	
	        	if(playerScores[i-1][j]==1000) {
	        		
	        		 System.out.print("____ ");
	        	}
	        	else if(playerScores[i-1][j] < 10) {
	        		
	       		 System.out.print("_"+ playerScores[i-1][j]+ "__ ");
	       	}
	        	else if(playerScores[i-1][j] >= 100) {
	        		
	        		System.out.print(playerScores[i-1][j] + "_ ");
	        	}
	        	else {
	        		
	        		System.out.print("_"+playerScores[i-1][j] + "_ ");
	        	}
	        		
	           
	        }
	        System.out.println(); //change line on console as row comes to end in the matrix.
	        
	        if(i==8) {System.out.println(); System.out.println("Lower Section:");}
	        if(i==16) System.out.println(); 
	     }
	}

 /**
  * 
  * @return the scoreboard
  */
public int [][] getPlayerScores() {
	return playerScores;
}


/**
 * 
 * @return the HashMap of score values
 */
public HashMap<String, Integer> getScoreValues() {
	return scoreValues;
}

	
	
}
