package tictactoe;
import java.util.Scanner;
//will need an import or two
public class Game {
	private Board gameBoard;
	private char currentPlayer; 
	// Stores users input
	private int location;

	

	/**
	 * Creates a new instance of board and sets the current player to X.
	 */
	public Game(){
		gameBoard= new Board();
		currentPlayer = 'X';
	}
	
	
	
	public void gameLoop () {
		
		Scanner a= new Scanner(System.in);
		
		while(true){
		  
			try {
		    System.out.println("\nPlayer "+currentPlayer+ " enter a location between 1 and 9: ");
		    location = a.nextInt();
			}
			//Input not an integer
			catch(Exception p) {
				System.out.println("\nLocation must be a NUMBER between 1 and 9.");
			    this.gameLoop();
			    break;
			}
		    
		    
		    try {
		    // Move made.
		    gameBoard.play(currentPlayer, location); 
		    }
		    //Number not in 1-9
		    catch(IllegalArgumentException e) {
		    	System.out.println("\nLocation must be between 1 and 9.");
			    this.gameLoop();
			    break;
		    	
		    }
		    //Spot already taken
		    catch(Exception f) {
		    	System.out.println("\nLocation already taken.");
			    this.gameLoop();
			    break;
		    }
		    
		    
		    
		    
		    // Checks for result 
		    if(gameBoard.hasWon(currentPlayer)== true) {
		    	 System.out.println("\nPlayer: " + currentPlayer + " has Won!!");
		    	 System.out.println("Game Over");
		    	break;
		    }
		    else if(gameBoard.isFull() == true) {
		    	System.out.println("\nThe game was a tie!");
		    	System.out.println("Game Over");
		    	break;
		    }
		    
			//Changing Player
		    if(currentPlayer == 'X') {
		    	currentPlayer = 'O';
		    }
		    else {
		    	currentPlayer = 'X';}
		    
			}
		
		
	}
	
	// helper functinos for gameLoop???
	
	// we discussed possibly using an:
	// int getPlayerMove() function
	// Note that there are two types of input errors:
	// 1) user enters letters, 2) user enters an integer outside of the
	// valid range (1-9)... error 1) can be handled in this class but error 2) should 
	// be handled in the Board class
}
