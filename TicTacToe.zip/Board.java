package tictactoe;

import java.util.Scanner;

public class Board {
	 private static final int SIZE = 3;
	 private static final char EMPTY = '_';
	    private char[][] currentBoard;
		
		/**
		 * Creates an empty Board
		 */
		public Board(){
			// code for initiallizing member variables here
			currentBoard = new char[SIZE][SIZE];
			for(int i=0; i<SIZE; i++) {
				for(int j=0; j<SIZE; j++) {
					currentBoard[i][j] = EMPTY;
				}
					
			}
		}
		
		/**
		 * Prints the board.
		 */
		public void printBoard(){
			for(int i=0; i<SIZE; i++) {
				for(int j=0; j<SIZE; j++) {
					System.out.print(currentBoard[i][j]);
				}
				System.out.print("\n");
			}
			
		}
		
		/**
		 * @param location should be between 1 and 9 inclusive
		 * @return 0-indexed row for the given location
		 */
		public static int getRow(int location){
			// Integer division truncates any fractional part
			return (location-1) / SIZE;
		}
		
		/**
		 * @return 0-indexed column for the given location
		 */
		public static int getColumn(int location){
		   // implement
			return (location-1) % 3;
		}
		
		/**
		 * Add move to the board
		 * @throws Exception if location is invalid or already full
		 */
		public void play(char currentPlayer, int location) throws Exception{
		   // implement and throw exception if invalid
			
		
			if(location>SIZE*SIZE || location <= 0) {
				throw new IllegalArgumentException("Location must be between 1 and 9.");
			}
			
			if(currentBoard[this.getRow(location)][this.getColumn(location)] != EMPTY) {
				throw new Exception("Location already taken.");
				
			}
			
			//Sets location's value to currentPlayer ("X" or "O")
			currentBoard[this.getRow(location)][this.getColumn(location)] = currentPlayer;
			
			this.printBoard();
			
		}
		
		/**
		 * @return true if the currentBoard already has an 'X' or an 'O' at
		 * [row][column].
		 */
		public boolean isFilled(int row, int col) {		
				return (currentBoard[row][col] != EMPTY);
		}
		
		/**
		 * @return true if all of the spaces on the board are occupied
		 */
		public boolean isFull(){
			for(int i=0; i<SIZE; i++) {
				for(int j=0; j<SIZE; j++) {
					 if(currentBoard[i][j] == EMPTY) {
						 return false;
					 }
				}
					
			}
			return true;
		}
		
		/**
		 * @return true currentPlayer has won the game
		 */
		public boolean hasWon(char currentPlayer) {
			// Checks rows and columns for wins
			int count = 0;
			int count2 = 0;
			
			for(int i=0; i<SIZE; i++) {
				for(int j=0; j<SIZE; j++) {
					 if(currentBoard[i][j] == currentPlayer) {
						 count ++;
					 }
					 if(currentBoard[j][i] == currentPlayer) {
						 count2 ++;
					 }
				}
				if(count == 3) {
					return true;
				}
				else if(count2 ==3) {
					return true;
				}
				else {
					count = 0;
					count2 = 0;
					}
					
			}
			
			// checks diagonals for wins
			if(currentBoard[0][2] == currentPlayer&&currentBoard[2][0] == currentPlayer&&currentBoard[1][1] == currentPlayer) {
				return true;
				
			}
			else if(currentBoard[0][0] == currentPlayer&&currentBoard[2][2] == currentPlayer&&currentBoard[1][1] == currentPlayer) {
				return true;
			}
			
			return false;
		}
}
