package tictactoe;

public class TicTacToe {
	
	public static void main(String[] args){
		// this should only be two lines
		Game a = new Game();
		a.gameLoop();
	}

}
