
public abstract class Cipher {

	
	public String encrypt(String s){
		StringBuilder result = new StringBuilder();
		for(int i=0; i<s.length(); i++){
			result.append(encrypt(s.charAt(i)));
		}
		return result.toString();
	}
	
	
	
	public String decrypt(String s){
		StringBuilder result = new StringBuilder();
		for(int i=0; i<s.length(); i++){
			result.append(decrypt(s.charAt(i)));
		}
		return result.toString();
	}
	
	
	abstract public char encrypt(char c);
	abstract public char decrypt(char c);
	
	abstract public Cipher newCopy();
	
	
	
	
	
}
