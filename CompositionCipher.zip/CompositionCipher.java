import java.util.ArrayList;

public class CompositionCipher extends Cipher{

	private ArrayList<Cipher> ciphers;
	
	
	
	public CompositionCipher(){
		ciphers = new ArrayList<>();
		
	}
	
/**
 * 
 * @param other- creates copy of a CompositionCipher object
 */
	public CompositionCipher(CompositionCipher other){
		// TODO: complete this copy constructor
		this.ciphers = new ArrayList<>();
		for(Cipher b : other.ciphers){
			add(b);
			
		}
	}
	
	/**
	 * 
	 * @param a - adds a copy of a Cipher to the Array List
	 */
	
	public void add(Cipher a) {
		ciphers.add(a.newCopy());
	}
	
	
	//encrypts character using different kinds of Ciphers
	@Override
	public char encrypt(char c) {
		
		/*for(Cipher k: ciphers) {
			 c = k.encrypt(c);
		}
		
		return c;*/
		
		for(int i=0; i < ciphers.size();i++){
			c = ciphers.get(i).encrypt(c);
        }
		
		return c;
		
	}
	
	//decrypts character using different kinds of Ciphers
	
	@Override
	public char decrypt(char c) {
		
		for(int i=ciphers.size() - 1; i >= 0;i--){
			c = ciphers.get(i).decrypt(c);
        }
		
		return c;
	}
	
	// Returns a new object, a deep copy of the current object
	@Override
	public Cipher newCopy() {
		// TODO Auto-generated method stub
		return new CompositionCipher(this);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
