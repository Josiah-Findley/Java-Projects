package project3;

import java.util.Random;

public class Program3 {

	public static int[] copyArray (int[] a) {
		// Create an array b[] of same size as a[] 
		int b[] = new int[a.length]; 

		// Copy elements of a[] to b[] 
		for (int i=0; i<a.length; i++) 
			b[i] = a[i]; 

		return b;

	}

	public static int[] mergeSort (int[] a) {
		int b[] = copyArray(a);
		int n = b.length;


		if (n > 1){

			int S1[];
			int S2[];


			//Partition the Array
			if(n%2!=0) {
				S1 = new int[(n+1)/2]; 
				for (int i=0; i<(n+1)/2; i++) 
					S1[i] = b[i]; 

				S2 = new int[(n-1)/2]; 
				for (int i=(n+1)/2; i<n; i++) 
					S2[i-(n+1)/2] = b[i]; 
			}	

			else {
				S1 = new int[n/2]; 
				for (int i=0; i<n/2; i++) 
					S1[i] = b[i]; 

				S2 = new int[n/2]; 
				for (int i=n/2; i<n; i++) 
					S2[i-n/2] = b[i]; 
			}

			S1 = mergeSort(S1);
			S2 = mergeSort(S2);



			int[] newS = merge(S1, S2);

			return newS;
		}	

		return b;


	}





	public static int[] merge (int[] a, int[] b) {

		int newS[] = new int[a.length+b.length];
		int counterA =0;
		int counterB =0;
		int newSCounter = 0;

		while (counterA != a.length && counterB != b.length) {
			if (a[counterA] <= b[counterB]){
				newS[newSCounter]=(a[counterA]);
				newSCounter++;
				counterA++;
			}
			else {
				newS[newSCounter]=(b[counterB]);
				newSCounter++;
				counterB++;
			}
		}
		while (counterA != a.length) {
			newS[newSCounter]=(a[counterA]);
			newSCounter++;
			counterA++;		
		}
		while (counterB != b.length) {
			newS[newSCounter]=(b[counterB]);
			newSCounter++;
			counterB++;			
		}
		return newS;

	}


	public static int[] heapSort (int[] a) {
		int b[] = copyArray(a);
		int n = b.length;
		int size;

		//orders the array up to index i-1 as a heap
		heapify(b, n);

		size = n - 1;
		while(size > 0) {
			int temp = b[0];
			b[0] = b[size];
			b[size] = temp;

			size--;
			downheap(0, b, size);
		}
		return b;
	}

	//This method builds the heap using bottom up construction
	//see pg 382 in textbook
	public static void heapify(int[] ary, int size) {
		int startIndex;
		if((size - 1) % 2 == 0) {
			startIndex = ((size - 1) - 2) / 2;
		} else {
			startIndex = ((size - 1) - 1) / 2;
		}
		//int startIndex = parent(size - 1);
		for(int j = startIndex; j >= 0; j--) {
			downheap(j, ary, size);
		}
	}

	//downheap helper method
	//code pulled from pg 378 in textbook
	//had to add the array and a size variable as parameters
	public static int[] downheap(int j, int[] ary, int size) {
		while((2 * j + 1) < size) {
			int child = 2 * j + 1;
			int swap = j;

			if(ary[swap] < ary[child]) {
				swap = child;
			}
			if((child + 1) < size && ary[swap] < ary[child + 1]) {
				swap = child + 1;
			}
			if(swap == j) {
				return ary;
			} 
			else {
				int temp = ary[j];
				ary[j] = ary[swap];
				ary[swap] = temp;
				j = swap;
			}
		}
		return ary;
	}





	public static int[] insertionSort (int[] a) {
		int b[] = copyArray(a);

		int n = b.length; 
		for (int i = 1; i < n; ++i) { 
			int key = b[i]; 
			int j = i - 1; 

			while (j >= 0 && b[j] > key) { 
				b[j + 1] = b[j]; 
				j = j - 1; 
			} 
			b[j + 1] = key; 
		} 

		return b;


	}

	public static int[] selectionSort (int[] a) {
		int b[] = copyArray(a);


		int n = b.length; 

		// One by one move boundary of unsorted subarray 
		for (int i = 0; i < n-1; i++) 
		{ 
			// Find the minimum element in unsorted array 
			int min = i; 
			for (int j = i+1; j < n; j++) 
				if (b[j] < b[min]) 
					min = j; 

			// Swap the found minimum element with the first 
			// element 
			int temp = b[min]; 
			b[min] = b[i]; 
			b[i] = temp; 
		} 

		return b;


	}
	public static int[] bubbleSort (int[] a) {
		int b[] = copyArray(a);

		int n = b.length; 
		for (int i = 0; i < n-1; i++) 
			for (int j = 0; j < n-i-1; j++) 
				if (b[j] > b[j+1]) 
				{ 
					// swap b[j+1] and b[i] 
					int temp = b[j]; 
					b[j] = b[j+1]; 
					b[j+1] = temp; 
				} 


		return b;

	}





	public static void main(String[] args) {
		String algNames[] = new String[5];
		int data[][]= new int[5][4];
		Random rand = new Random();

		algNames[0] = "Selection Sort Avg Times: ";
		algNames[1] = "Insertion Sort Avg Times: ";
		algNames[2] = "Bubble Sort Avg Times: ";
		algNames[3] = "Heap Sort Avg Times: ";
		algNames[4] = "Merge Sort Avg Times: ";

		for(int k =0; k<4; k++) {
			int Array_Size = (int) Math.pow(10,k+1);
			int array[] = new int[Array_Size];


			for(int i = 0; i < Array_Size; i++) {
				array[i] = rand.nextInt(Array_Size);
			}

			int sumTimes[] = new int [5];
			//   //1.0 Initialize
			//   for (int i = 0; i < Array_Size; i++) {
			//		    array[i] = i; //fill the array with value of index
			//   }
			//   
			//   int sumTimes[] = new int [5];
			//   
			for(int j =0; j<10; j++) {
				//		    Random random = new Random();
				//		    //Shuffle array
				//		    for (int i = 0; i < Array_Size; i++) {
				//		     int a = random.nextInt(Array_Size); //first random number
				//		     int b = random.nextInt(Array_Size); //second random number
				//		     int c = array[a]; // save stuff in array[a]
				//		     array[a] = array[b]; //swap stuff of a and stuff of b
				//		     array[b] = c;
				//		    }

				//Print array
				//        for (int i = 0; i < Array_Size; i++)
				//        {
				//          System.out.println(array[i]);
				//        }
				long start = System.nanoTime();
				int selectionSort[] = selectionSort (array);
				long finish = System.nanoTime();
				long timeInMSecs = (finish-start)/1000;
				sumTimes[0] += timeInMSecs;

				start = System.nanoTime();
				int insertionSort[] = insertionSort (array);
				finish = System.nanoTime();
				timeInMSecs = (finish-start)/1000;
				sumTimes[1] += timeInMSecs;

				start = System.nanoTime();
				int bubbleSort[] = bubbleSort (array);
				finish = System.nanoTime();
				timeInMSecs = (finish-start)/1000;
				sumTimes[2] += timeInMSecs;

				start = System.nanoTime();
				int heapSort[] = heapSort (array);
				finish = System.nanoTime();
				timeInMSecs = (finish-start)/1000;
				sumTimes[3] += timeInMSecs;

				start = System.nanoTime();
				int mergeSort[] = mergeSort (array);
				finish = System.nanoTime();
				timeInMSecs = (finish-start)/1000;
				sumTimes[4] += timeInMSecs;

			}//j for loop  


			for(int j =0; j<5; j++) {
				data[j][k] = sumTimes[j]/10;
			}


		}//k for loop


		System.out.printf("%30s%20d%20d%20d%20d\n\n", "Input size:", 10, 100, 1000, 10000);

		for (int i = 0; i < data.length; i++) {
			System.out.printf("%30s", algNames[i]);
			for (int j = 0; j < data[i].length; j++) {

				System.out.printf("%20d", data[i][j]);
			}
			System.out.println();
		}


	}



}
