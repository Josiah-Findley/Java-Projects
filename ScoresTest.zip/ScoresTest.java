import org.junit.jupiter.api.Test;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ScoresTest {

	@Test 
    public void emptyString(){
		final String empty = "";
		Score a = new Score(empty);
		int result = a.getMax();
		int result2 = a.getNumScores();
		assertEquals(Integer.MIN_VALUE, result);//(expected, actual)
		assertEquals(0, result2);//(expected, actual)
		
		try {
			a.get(0);
			fail("Should not reach this point.");
			}catch(Exception b) {
				
				
			}

	}	

	@Test
	public void handleExceptions() {
		final String x = " /n asdf -234 34 53";
		try {
		Score a = new Score(x);
		fail("Should not reach this point.");
		}catch(IllegalArgumentException b) {
			
			
		}
		final String x2 = "-234 34 53 /n sfasd";
		try {
			Score b = new Score(x2);
			fail("Should not reach this point.");
			}catch(IllegalArgumentException b) {
				
				
			}
		
		
	}
		
	@Test
	public void validnegativeString() {
			final String x = " \n -1 -34 -53 -234";
			
			Score a = new Score(x);
			int result = a.getMax();
			int result2 = a.get(2);
			int result3 = a.getNumScores();

			assertEquals(-1, result);//(expected, actual)
			assertEquals(-53, result2);//(expected, actual)
			assertEquals(4, result3);//(expected, actual)
			
			final String x2 = " \n -234 -34 -53 -2";
			
			Score c = new Score(x2);
			int result4 = c.getMax();
			assertEquals(-2, result4);//(expected, actual)
			
			try {
			Score b = new Score(x);
			
			}catch(IllegalArgumentException d) {
				fail("This is a valid string.");
				
			}
			
			try {
				a.get(5);
				fail("Should not reach this point.");
				}catch(Exception b) {
					
					
				}
			
			
			
			
	}
	
	@Test 
	public void validpositiveString() {
		final String x = "234 \n 34 53 534 \n";
		
		Score a = new Score(x);
		int result = a.getMax();
		int result2 = a.get(2);
		int result3 = a.getNumScores();

		assertEquals(534, result);//(expected, actual)
		assertEquals(53, result2);//(expected, actual)
		assertEquals(4, result3);//(expected, actual)
		
		final String x2 = "534 \n 34 53 234 \n";
		
		Score c = new Score(x2);
		int result4 = c.getMax();
		assertEquals(534, result4);//(expected, actual)
		
		try {
		Score b = new Score(x);
		
		}catch(IllegalArgumentException e) {
			fail("This is a valid string.");
			
		}
		
		try {
			a.get(5);
			fail("Should not reach this point.");
			}catch(Exception b) {
				
				
			}
		
		
		
		
}
	
	
	
	@Test 
	public void validposnegString() {
		final String x = "-234 \n 34 -53 534";
		
		Score a = new Score(x);
		int result = a.getMax();
		int result2 = a.get(2);
		int result3 = a.getNumScores();

		assertEquals(534, result);//(expected, actual)
		assertEquals(-53, result2);//(expected, actual)
		assertEquals(4, result3);//(expected, actual)
		
		final String x2 = "534 \n -34 -53 234";
		
		Score c = new Score(x2);
		int result4 = c.getMax();
		assertEquals(534, result4);//(expected, actual)
		
		try {
		Score b = new Score(x);
		
		}catch(IllegalArgumentException e) {
			fail("This is a valid string.");
			
		}	
		
		try {
			a.get(5);
			fail("Should not reach this point.");
			}catch(Exception b) {
				
				
			}
}

	
	@Test
	public void nullstuff() {
			final String x = null;
			try {
				Score b = new Score(x);
				fail("Should not reach this point.");
				}catch(NullPointerException c) {
				
					
				}
	}
	
	
	
}
