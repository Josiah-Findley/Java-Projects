import java.sql.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

public class DBConnector {



    /**
     * Object that stores the connection to the database
     */
    private Connection conn;
    private ArrayList<PreparedStatement> running;

    /**
     * This class represents a timeslot that has a starting time, day and an integer duration.
     */
    class Timeslot {
        String startingTime;
        String day;
        int duration;
    }

    /**
     * This constructor should create and initialize the connection to the database.
     * @param username the mysql username
     * @param password the mysql password
     * @param schema the mysql schema
     */
    public DBConnector(String username, String password, String schema) throws SQLException {
        Properties info = new Properties();
        info.put("user", username);
        info.put("password", password);
        conn = DriverManager.getConnection("jdbc:mysql://COMPDBS300/"+schema, info);
        running = new ArrayList<>();
    }

    /**
     * Displays the description, hosting organization names, and the first category name of each project
     */
    public void listAllProjects() {
        var query = "SELECT PROJECT.DESCRIPTION \"Description\", ORGANIZATION.NAME \"Organization\", " +
                    "CATEGORY.NAME \"Category\" FROM PROJECT JOIN HOSTS USING(PROJID) JOIN ORGANIZATION " +
                    "USING(ORGNO) JOIN PROJECTCAT USING(PROJID) JOIN CATEGORY USING(CATID) WHERE RANKING = 1";
        try (var stmt = conn.prepareStatement(query)) {
            try {
                running.add(stmt);
                stmt.execute();
                System.out.println("\n\tPROJECTS\n" + formatResult(stmt.getResultSet()));
            } finally { running.remove(stmt); }
        } catch (SQLException sqle) { sqle.printStackTrace(); }
    }

    /**
     * Displays all projects from a specific date.
     * @param date the project date
     */
    public void findProjectByDate(String date) {
        if (!validDate(date)) {
            System.err.println("Invalid date format!");
            return;
        }
        var query = "SELECT * FROM PROJECT WHERE STARTINGDATE = ?";
        try (var stmt = conn.prepareStatement(query)) {
            try {
                running.add(stmt);
                stmt.setString(1, date);
                stmt.execute();
                System.out.println("\n\tPROJECTS BY DATE\n" + formatResult(stmt.getResultSet()));
            } finally { running.remove(stmt); }
        } catch (SQLException sqle) { sqle.printStackTrace(); }
    }

    /**
     * Displays the names of all volunteers who live in the specified town or city
     * @param town the name of the town or city
     */
    public void findVolunteersByLocation(String town) {
        var query = "SELECT NAME FROM VOLUNTEER WHERE ADDRESS LIKE ?";
        try (var stmt = conn.prepareStatement(query)) {
            try {
                running.add(stmt);
                stmt.setString(1, "%"+town+"%");
                stmt.execute();
                System.out.println("\n\tVOLUNTEERS BY LOCATION\n" + formatResult(stmt.getResultSet()));
            } finally { running.remove(stmt); }
        } catch (SQLException sqle) { sqle.printStackTrace(); }
    }

    /**
     * Display all the project IDs and descriptions of projects that belong to the specified category
     * @param name name of the project category
     */
    public void searchByCategory(String name) {
        var query = "SELECT PROJID, DESCRIPTION FROM PROJECTCAT JOIN PROJECT USING(PROJID) " +
                    "WHERE CATID IN (SELECT CATID FROM CATEGORY WHERE NAME = ?)";
        try (var stmt = conn.prepareStatement(query)) {
            try {
                running.add(stmt);
                stmt.setString(1, name);
                stmt.execute();
                if (stmt.execute() && stmt.getResultSet().first())
                    System.out.println("\n\tPROJECTS BY CATEGORY\n" + formatResult(stmt.getResultSet()));
                else System.err.println("Cannot find category " + name);
            } finally { running.remove(stmt); }
        } catch (SQLException sqle) { sqle.printStackTrace(); }
    }

    /** Search by keywords: Display all the project IDs and descriptions of
     * projects whose description matches the keywords entered.
     * Outputs: displays project IDs and descriptions of projects whose description matches the keywords entered
     * Action: using a single SQL query, this method searches the database for the requested data.
     * Error handling: print an error message if there are no projects that match the keywords.
     *
     * @param keywords one or more keywords as.
     */
    public void searchByKeywords(String[] keywords) {
        StringBuilder queryBuilder = new StringBuilder("SELECT PROJID, DESCRIPTION FROM PROJECT WHERE");
        for (String word : keywords)
            queryBuilder.append(" DESCRIPTION LIKE \"%").append(word).append("%\" OR");
        var query = queryBuilder.toString().substring(0, queryBuilder.toString().length() - 2).trim();

        try (var pstmt = conn.prepareStatement(query)) {
            try {
                running.add(pstmt);
                var result = pstmt.executeQuery();
                if (result.first()) System.out.println("\n\tKEYWORD RESULTS\n" + formatResult(result));
                else System.err.println("No results found.");
            } finally { running.remove(pstmt); }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    /** List needed volunteers: This should allow the user to view the number of
     *  volunteers still needed for each timeslot belonging to a particular project.
     *  Outputs: a table containing the date and starting time for each timeslot along with the number of volunteers still needed.
     *  Action: This method should use a single SQL query to search the database for the timeslots belonging to a project and calculating the number of volunteers needed.
     *  Error handling: print an error message if the projID is not valid.
     *  @param projID int value representing a valid projID.
     */
    public void neededVolunteers(int projID) {
        var query = "SELECT DAY, STARTINGTIME, TIMESLOT.NVOLNEEDED - VOL \"Vols still needed\" FROM TIMESLOT JOIN " +
                    "PROJECT USING(PROJID) JOIN (SELECT COUNT(*) VOL, DAY, STARTINGTIME, PROJID FROM PROJVOLUNTEERS " +
                    "JOIN TIMESLOT USING (DAY, STARTINGTIME, PROJID) GROUP BY DAY, STARTINGTIME, PROJID) YA USING(" +
                    "DAY, STARTINGTIME, PROJID) WHERE PROJID = ?";
        try (var pstmt = conn.prepareStatement(query)) {
            try {
                running.add(pstmt);
                pstmt.setInt(1, projID);
                var result = pstmt.executeQuery();
                if (result.first()) System.out.println("\n\tNEEDED VOLUNTEERS\n" + formatResult(result));
                else System.err.println("Invalid Project ID");
            } finally { running.remove(pstmt); }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    /** Change the duration of a timeslot: change the duration of a timeslot to a new value.
     * Outputs: displays a message that the duration was changed. Returns true if successful, false otherwise
     * Action: updates the duration of the specified timeslot in the database
     * Error handling: print an error message if the timeslot cannot be found.
     * @param projID: project ID
     * @param date: date of timeslot
     * @param time: starting time of timeslot
     * @param newDuration: new duration as inputted from the user.
     */
    public boolean changeDuration(int projID, String date, String time, int newDuration) {
        if (!validDate(date)) {
            System.err.println("Invalid date format!");
            return false;
        }
        var query = "UPDATE TIMESLOT SET DURATION = ? WHERE PROJID = ? AND STARTINGTIME = ? AND DAY = ?";
        try (var pstmt = conn.prepareStatement(query)) {
            try {
                running.add(pstmt);
                pstmt.setInt(1, newDuration);
                pstmt.setInt(2, projID);
                pstmt.setString(3, time);
                pstmt.setString(4, date);
                if (pstmt.executeUpdate() == 0) System.err.println("Timeslot not found.");
                else System.out.println("Update complete.");
            } finally { running.remove(pstmt); }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        }
        return true;
    }

    /** Volunteer for a timeslot: this method allows the user to volunteer for a timeslot.
     * Outputs: displays a message that the sign up was complete/incomplete.
     * Action: this method has two actions:
     * Make sure that the timeslot is available: It should check if the status of the project is and then compare the number of volunteers registered to the number of volunteers needed for the timeslot. If more volunteers are needed for this timeslot, then proceed to Action ii. Otherwise, display a message notifying the volunteer that this timeslot is fulfilled.
     * Insert the necessary data into the database.
     * Error handling: print an error message if the timeslot cannot be found or the volunteer ID cannot be found.
     * @param projID project ID
     * @param date of timeslot
     * @param time starting time of timeslot
     * @param VolID volunteer ID as inputted from the user.
     */
    public boolean volunteer (int projID, String date, String time, int VolID) {
        if (!validDate(date)) {
            System.err.println("Invalid date format!");
            return false;
        }
        try {

            // finds status
            PreparedStatement pstmt2 = conn.prepareStatement("select status from project where projID = ?;");
            pstmt2.setInt(1, projID);
            ResultSet rst2 = pstmt2.executeQuery();

            String status ="";

            if (rst2.first()) status = rst2.getString(1);
            else {
                System.err.println("Invalid Project!");
                pstmt2.close();
                return false;
            }
            pstmt2.close();

            // finds # of volunteers signed up
            PreparedStatement pstmt4 = conn.prepareStatement(
                    "select count(*) from projvolunteers join timeslot using (day, startingTime, projID) where day = ? and startingTime = ? and projID = ?;");
            pstmt4.setString(1, date);
            pstmt4.setString(2, time);
            pstmt4.setInt(3, projID);
            ResultSet rst3 = pstmt4.executeQuery();

            int numVol;

            if (rst3.first()) numVol = rst3.getInt(1);
            else {
                System.err.println("Timeslot does not exist!");
                return false;
            }
            pstmt4.close();

            // finds # nvolunteers
            PreparedStatement pstmt3 = conn.prepareStatement(
                    "select nVolneeded from timeslot where day = ? and startingTime = ? and projID = ?;");
            pstmt3.setString(1, date);
            pstmt3.setString(2, time);
            pstmt3.setInt(3, projID);

            ResultSet rst4= pstmt3.executeQuery();

            int needVol;

            if (rst4.first()) needVol = rst4.getInt(1);
            else {
                System.err.println("Invalid timeslot!");
                pstmt3.close();
                return false;
            }
            pstmt3.close();

            if(status.toLowerCase().equals("open") && needVol>numVol) {
                var query = "INSERT INTO PROJVOLUNTEERS VALUES(?, ?, ?, ?)";
                try (var pstmt = conn.prepareStatement(query)) {
                    try {
                        running.add(pstmt);
                        pstmt.setInt(1, VolID);
                        pstmt.setInt(2, projID);
                        pstmt.setString(3, date);
                        pstmt.setString(4, time);
                        pstmt.executeUpdate();
                    } catch (SQLException e) {
                        System.err.println("Volunteer ID is invalid!");
                        return false;
                    } finally { running.remove(pstmt); }
                }
            } else {
                System.out.println("The time slot you are requesting is fulfilled.");
                return false;
            }
            System.out.println("Insertion Complete.");

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }

        return true;
    }
    /** Add a project: the user needs to specify the information about the project.
     * Then, the application adds the new project to the database.
     * Output: a confirmation message when the project has been inserted
     * Action: this method inserts the project into the database. There are multiple insertions and queries as part of this method. You can use helper methods to split up the work.
     * Error handling: print an error message if the enddate is earlier than startingDate or if startingDate is earlier than todays date or if the user specified a category that does not exist.
     * @param orgNo Organization number
     * projID calculated by the application by incrementing the highest projID in the database.
     * @param description
     * @param startingDate
     * @param endDate
     * @param location
     * @param nVolunteers number of volunteers needed
     * @param categories one or more categories   as category name. If more than one category is inputted, the order by which they are inputted indicates their ranking, e.g., the first category has ranking 1.
     * @param timeslots one or more timeslots
     */

    public boolean addProject(int orgNo, String description, String startingDate, String endDate, String location, int nVolunteers, String [] categories, Timeslot[] timeslots) {
        if (!validDate(startingDate)) {
            System.err.println("Invalid starting date format!");
            return false;
        } else if (!validDate(endDate)) {
            System.err.println("Invalid ending date format!");
            return false;
        } else if (Date.valueOf(startingDate).after(Date.valueOf(endDate))) {
            System.err.println("Starting date cannot come after ending date!");
            return false;
        } else if (Date.valueOf(startingDate).before(Date.from(Instant.now()))) {
            System.err.println("Starting date cannot be in the past!");
            return false;
        }
        
    

        try {

            conn.setAutoCommit(false);
            // Find Project ID
            PreparedStatement pstmt2 = conn.prepareStatement("select max(projID) from project;");

            ResultSet rst2 = pstmt2.executeQuery();

            int projID = 0;
            while (rst2.next()) {
                projID = rst2.getInt(1) + 1;
            }

            pstmt2.close();

            // if() check dates

            // insert into project
            PreparedStatement pstmt = conn.prepareStatement("insert into project values(?, ?, ?, ?, ?, ?, ?);");
            pstmt.setInt(1, projID);
            pstmt.setString(2, description);
            pstmt.setString(3, startingDate);
            pstmt.setString(4, endDate);
            pstmt.setString(5, location);
            pstmt.setInt(6, nVolunteers);
            pstmt.setString(7, "open");
            pstmt.executeUpdate();
            pstmt.close();

            // insert into Hosts
            PreparedStatement pstmt3 = conn.prepareStatement("insert into hosts values(?, ?);");
            pstmt3.setInt(1, orgNo);

            pstmt3.setInt(2, projID);

            pstmt3.executeUpdate();

            pstmt3.close();

            // Insert into ProjectCat
            int rank = 1;

            for (String cat : categories) {

                // Find catID
                PreparedStatement pstmt5 = conn.prepareStatement("select catID from category where name = ?;");
                pstmt5.setString(1, cat);

                int catID = 0;
                ResultSet rst3 = pstmt5.executeQuery();
                if (rst3.first()) catID = rst3.getInt(1);
                else {
                    System.err.println("Category " + cat + " does not exist!");
                    continue;
                }
                pstmt5.close();

                PreparedStatement pstmt4 = conn.prepareStatement("insert into ProjectCat values(?, ?, ?);");
                pstmt4.setInt(1, rank);

                pstmt4.setInt(2, projID);

                pstmt4.setInt(3, catID);

                pstmt4.executeUpdate();

                pstmt4.close();

                rank++;
            }

            // Insert into TimeSlot

            for (Timeslot a : timeslots) {

                PreparedStatement pstmt6 = conn.prepareStatement("insert into timeslot values(?, ?, ?, ?, ?);");
                pstmt6.setString(1, a.day);
                pstmt6.setString(2, a.startingTime);
                pstmt6.setInt(3, nVolunteers);
                pstmt6.setInt(4, a.duration);
                pstmt6.setInt(5, projID);

                pstmt6.executeUpdate();

                pstmt6.close();

            }

            System.out.println("Insertion Complete.");

           conn.commit();
            conn.setAutoCommit(true);

        } catch (SQLException e) {
            // TODO Auto-generated catch block
           System.err.println(e.getMessage());
            return false;
        }

        return true;
    }
    /**
     * This method implements the functionality necessary to exit the application:
     * this should allow the user to cleanly exit the application properly.
     * This should close the connection and any prepared statements.
     */
    public void exitApplication() {
        try { conn.close();
            for (PreparedStatement stmt : running) stmt.cancel();
        } catch (SQLException ignore){}
    }

    private boolean validDate(String date) {
    	try {
    		Date.valueOf(date);
    		return true;
    	}catch(Exception e) {
    		return false;
    		
    	}
        
    }

    /**
     * @param result {@link ResultSet} of the table to format
     * @return A formatted string to display the table from the {@link ResultSet}
     * @throws SQLException
     */
    private String formatResult(ResultSet result) throws SQLException {

        var output = new StringBuilder();   // formatted table to print
        var meta = result.getMetaData();    // metadata
        var cols = meta.getColumnCount();   // number of columns
        var widths = new int[cols];         // max width of each column

        result.beforeFirst();
        // update max widths with column entry data and labels
        while (result.next()) {
            for (int i = 0; i < cols; i++) {
                var data = result.getObject(i + 1);
                widths[i] = Math.max(widths[i], data != null ? data.toString().length() : 4);
            }
        }
        for (int i = 0; i < cols; i++)
            widths[i] = Math.max(widths[i], meta.getColumnLabel(i+1).length());
        result.beforeFirst();

        // top horizontal line and column names
        var hLine = "  " + new String(new char[Arrays.stream(widths).sum()+3*cols-1]).replace('\0', '-') + "\n";
        output.append(hLine).append(" | ");
        for (int i = 0; i < cols; i++) {
            var label = meta.getColumnLabel(i+1);
            output.append(label)
                    .append(new String(new char[widths[i] - label.length()]).replace('\0', ' '))
                    .append(" | ");
        }

        // internal horizontal line
        output.append("\n |");
        for (int i = 0; i < cols; i++)
            output.append(new String(new char[widths[i] + 2]).replace('\0', '-')).append("|");
        output.append('\n');

        // rows
        while (result.next()) {
            output.append(" | ");
            for (int i = 0; i < cols; i++) {
                var data = result.getObject(i+1);
                var init = data != null ? data.toString() : "null";
                output.append(init)
                        .append(new String(new char[widths[i] - init.length()]).replace('\0', ' '))
                        .append(" | ");
            }
            output.append('\n');
        }

        return output.append(hLine).toString();
    }


    
    
    

		
		
	}

