import java.sql.SQLException;


public class DBApplication {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		
		
		
        var dbc = new DBConnector("u258577", "p258577", "schema258577");
        dbc.listAllProjects();
        dbc.findProjectByDate("2020-02-09");
        dbc.findVolunteersByLocation("Grove City PA");
        dbc.searchByCategory("service");
        dbc.neededVolunteers(2211);
        dbc.changeDuration(2211, "2020-02-09", "14:00:00", 10000);
        String[] keys = {"baby", "lebanese"};
        dbc.searchByKeywords(keys);
        //TODO: error handling when inputs are invalid (LOOK AT ORIGINAL STARTER CODE FOR JAVADOC)

		String[] cat = {"service", "fundraiser"};	
		DBConnector.Timeslot b = dbc.new Timeslot();
		b.day= "2020-02-09";
		b.duration= 4;
		b.startingTime= "14:00:00";	
		DBConnector.Timeslot[] t = {b};
		boolean k =dbc.addProject(10002, "Helloo", "2020-02-09", "2020-09-19", "The Park", 7, cat, t);

		System.out.println(k);
		boolean r = dbc.volunteer (2211, "2020-02-09", "10:00:00", 5688);
		System.out.println(r);
		
		dbc.exitApplication();
	}

}
