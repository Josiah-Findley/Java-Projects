package proj2;

public class SpellingNode {
	 char value;
	 SpellingNode [] children;
	 boolean correctWord;
	 
	 public SpellingNode(char value) {
	  this.value = value;
	  children = new SpellingNode[26];
	  correctWord = false;
	 }
	 
	 public void setCorrect() {
	  correctWord = true;
	 }
	 
	 public boolean getCorrect() {
	  return correctWord;
	 }
	 
	 
	 
	 public boolean addChild(char val) {
		  int index = val % 65;
		  if(this.children[index] != null && 
		    this.children[index].value == val) {
		   return false;
		  }
		  SpellingNode newChild = new SpellingNode(val);
		  this.children[index] = newChild;
		  return true;
		  }
		 
		 public SpellingNode getChildAt(char val) {
		  int index = val % 65;
		  return this.children[index];
		 }
		 
}