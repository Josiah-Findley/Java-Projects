package proj2;

public class SpellingTree {
	 SpellingNode root;
	 
	 public SpellingTree() {
	  root = new SpellingNode(' ');
	 }
	 
	 public boolean addWord(String word) {
		 word = word.toUpperCase();
	  SpellingNode currNode = this.root;  //can I do this??
	  
	  for(int i = 0; i < word.length(); i++) {
	   char currChar = word.charAt(i);
	   currNode.addChild(currChar);
	   currNode = currNode.getChildAt(currChar);
	   if(i== word.length()-1) {
		   currNode.setCorrect();
	   }
	  }
	  return true;
	 }
	 
	 public boolean checkWord(String word) {
		 word = word.toUpperCase();
		 SpellingNode currNode = root;
		 for(int i = 0; i < word.length(); i++) {
			   char currChar = word.charAt(i);
			   if(currNode.getChildAt(currChar)==null) {
				   return false;
			   }
			   currNode = currNode.getChildAt(currChar);
			   
			   if(i== word.length()-1&&currNode.getCorrect()) {
				   return true;
			   }
			  }
		 return false;
	 }
	 
	 public void printWords(String subWord, SpellingNode c) {
		 for (SpellingNode child : c.children){
			if(child != null) { 
		 	subWord+= child.value;
		 	if(child.getCorrect()) {
		 		System.out.println(subWord);
		 	}
		 	printWords(subWord, child);
		 	subWord = subWord.substring(0, subWord.length()-1);
			}
		 }
	 }
	 
	 
	}