package proj2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SpellChecker {
	
	static SpellingTree mytree;

	public static void main(String[] args) throws FileNotFoundException {
		mytree = new SpellingTree();
		readWords("dictionary");
		mytree.printWords("", mytree.root);
		System.out.println();
		int k = checkWords("check");
		if(k==1) {
			System.out.print("is incorrectly spelled. ");
			System.out.println("You made "+k+" mistake.");
		}
		if(k>1) {
			System.out.print(": These are all incorrectly spelled. ");
			System.out.println("You made "+k+" mistakes.");
		}		
		
		
		System.out.println("\n\n<<<Normal Termination>>>");
	}

	
	public static void readWords(String filename) throws FileNotFoundException {
		File f = new File(filename);
		Scanner in = new Scanner(f);		
		while(in.hasNext()) {
			String word = in.next();
			mytree.addWord(word);
		}
		
		
				
	}
	
	public static int checkWords(String filename) throws FileNotFoundException {
		int totalWrong =0;
		File f = new File(filename);
		Scanner in = new Scanner(f);		
		while(in.hasNext()) {
			String word = in.next();
			//Assuming only correct punctuation is at end on a word
			if(!Character.isLetter(word.charAt(word.length()-1))) {
				word = word.substring(0, word.length()-1);
			}
			if(!mytree.checkWord(word)) {
				System.out.print(word+" ");
				totalWrong++;
			}
		}	
		
		return totalWrong;
	}
	
	
	
}

