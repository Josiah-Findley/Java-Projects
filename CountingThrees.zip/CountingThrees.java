
/************************************************
**Josiah Findley ~ COMP233.A ~ Spring 2020****
**
**Find the number of 3's in a random array
*************************************************/
public class CountingThrees implements Runnable{
	private static final int MAX = 1<<28;	//256 MEG
	private static final int NUM_THREADS = 2;
	
	private static int[] ary;
	private static int numThrees;
	private Object mutex = new Object();  //we need a mutex
	
	
	//Each thread will execute this routine in parallel
		public void run() {
			
			//We will do SPMD work distribution
			String tName = Thread.currentThread().getName();
			int low, high;	//our workspace in the array
			int i=0;
			int localCnt = 0;
			
			//find our workload range from our name: Thread0, Thread1, etc.
			int myID = Character.getNumericValue(tName.charAt(tName.length()-1));
			
			//straight up SPMD
			low = (myID * MAX)/NUM_THREADS;
			high = ((myID+1) * MAX)/NUM_THREADS;
			
			
			//Now go do our bit
					for (int j=low; j<high; j++)
						if (ary[j] == 3)  //count the 3's
							localCnt++;
					
					//Poor man's reduction: a mutex lock
					synchronized (mutex) {
						numThrees += localCnt;
						//System.out.println (tName + " counted " + localCnt + " threads");
					}
			}//run

	
	public static void main(String[] args) {
		int i;
		int serialCount3 = 0;
		Thread[] threadAry = new Thread[NUM_THREADS];
			
		System.out.println("Counting Threes in " + String.format("%,d",  MAX)
				+ " random integers\n");
			
			//init the ary with ints [0,9]
			ary = new int[MAX];
			for (i=0; i<MAX; i++) {
				ary[i] = (int) (10 * Math.random());
			}

			//create our thread team
			numThrees = 0;
			Runnable a = new CountingThrees();
			for (i=0; i<NUM_THREADS; i++)
				threadAry[i] = new Thread(a);

			//make a serial count of 3's
			long startTime = System.currentTimeMillis();
			for (i=0; i<MAX; i++)
				if (ary[i]==3) serialCount3++;
				long endTime = System.currentTimeMillis();
				
			//print the results
			System.out.println("\tThere are " + 
						String.format("%,d", serialCount3)
						+ " threes in the list");
			System.out.println("\tThat took " + (endTime-startTime) 
					+ " mSecs\n");
			
			//Now release the threads
			startTime = System.currentTimeMillis();
			for (i=0; i<NUM_THREADS; i++) {
					threadAry[i].start();
			}
					
			try { //wait for all threads to finish
				for (i=0; i<NUM_THREADS; i++) 
					threadAry[i].join();
			}catch (InterruptedException e) 
					{ /* ignore */ }
			endTime = System.currentTimeMillis();

			//print the parallel results
			System.out.println(NUM_THREADS+" threads counting Threes in " 
			+ String.format("%,d",  MAX) + " random integers\n");
			
			System.out.println("\tThere are " + 
						String.format("%,d", numThrees)
						+ " threes in the list");
			System.out.println("\tThat took " + (endTime-startTime) 
					+ " mSecs\n");
			//Normally terminated
			System.out.println("\n\t<<Normal Termination>>\n");

	}
	
}
	
	
	
	
	
	


